/**
 * ТУР ПУТЬ — Модуль интеграции с CRM Tourclick (Турклик)
 * и автоматической синхронизации отелей, цен и направлений.
 *
 * Архитектурные функции:
 * 1. Tourclick.sendLead(data) — передача заявок клиентов напрямую в CRM Турклик.
 * 2. Tourclick.sync — модуль авто-обновления отелей, фото и цен из внешнего файла/API.
 * 3. Локальная очередь (Offline Guard) — если связь с CRM прервалась, заявка гарантированно
 *    сохраняется в защищенную очередь, а в Telegram админа отправляется сигнал тревоги.
 */

(function(){
  'use strict';

  const STORAGE_CONFIG_KEY = 'turput_tourclick_url';
  const STORAGE_QUEUE_KEY = 'turput_tourclick_queue';
  const STORAGE_TOURS_KEY = 'turput_tours_catalog';

  const Tourclick = {
    // Получение настроенного Webhook URL Турклик
    getWebhookUrl: function(){
      try {
        return localStorage.getItem(STORAGE_CONFIG_KEY) || (window.TURPUT_CONFIG && window.TURPUT_CONFIG.tourclickWebhook) || '';
      } catch(e){
        return '';
      }
    },

    setWebhookUrl: function(url){
      try {
        localStorage.setItem(STORAGE_CONFIG_KEY, String(url || '').trim());
      } catch(e){}
    },

    // Очередь сохраненных заявок
    getLeadsQueue: function(){
      try {
        const raw = localStorage.getItem(STORAGE_QUEUE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch(e){
        return [];
      }
    },

    saveToQueue: function(lead){
      try {
        const q = this.getLeadsQueue();
        q.unshift(lead);
        localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(q.slice(0, 50)));
      } catch(e){}
    },

    // Сбор UTM-меток маркетолога
    getUtmTags: function(){
      const utm = {};
      try {
        const params = new URLSearchParams(window.location.search);
        ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(k => {
          if(params.has(k)) utm[k] = params.get(k);
        });
      } catch(e){}
      return utm;
    },

    /**
     * Отправка заявки клиента в Tourclick CRM
     * @param {Object} formData { name, phone, direction, dateFrom, tourists, comment }
     * @returns {Promise<{ ok: boolean, message: string }>}
     */
    sendLead: async function(formData){
      const utm = this.getUtmTags();
      const payload = {
        id: 'tc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        name: String(formData.name || '').trim(),
        phone: String(formData.phone || '').trim(),
        direction: String(formData.direction || '').trim(),
        dateFrom: formData.dateFrom || '',
        tourists: formData.tourists || '2',
        comment: String(formData.comment || '').trim(),
        utm: utm,
        pageUrl: window.location.href,
        referrer: document.referrer || '',
        createdAt: new Date().toISOString(),
        status: 'new'
      };

      // Всегда сохраняем в локальную очередь для гарантии сохранности
      this.saveToQueue(payload);

      const endpoint = this.getWebhookUrl();

      // Если URL Турклик еще не внесен — работаем в режиме безопасного накопления
      if(!endpoint){
        console.log('[Tourclick] Webhook URL еще не указан. Заявка сохранена в локальной очереди:', payload);
        return {
          ok: true,
          mode: 'offline_queue',
          message: 'Заявка принята и сохранена локально. Подключите Webhook Турклик в админ-панели для автоматической отправки в CRM.'
        };
      }

      // Отправка в реальный Турклик через Webhook / REST API
      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        if(!response.ok){
          throw new Error('Tourclick CRM вернул статус ошибки: ' + response.status + ' (' + response.statusText + ')');
        }

        let resData = null;
        try { resData = await response.json(); } catch(e){}

        return {
          ok: true,
          mode: 'crm_synced',
          crmResponse: resData,
          message: 'Заявка успешно доставлена в Tourclick CRM!'
        };
      } catch(err){
        // При сбое отправки в CRM вызываем системный детектор ошибок!
        // Детектор автоматически отправит экстренный алерт в Telegram владельца сайта!
        if(window.TurputSecurity && typeof window.reportError === 'function'){
          window.reportError(
            'Сбой отправки лида в Tourclick CRM: ' + (err && err.message || err),
            'Tourclick.sendLead',
            { clientName: payload.name, clientPhone: payload.phone, direction: payload.direction }
          );
        }
        throw err;
      }
    },

    // --- МОДУЛЬ СИНХРОНИЗАЦИИ ОТЕЛЕЙ И ЦЕН (TOUR & HOTEL SYNC) ---
    sync: {
      /**
       * Загрузка каталога отелей и направлений из JSON-файла или API
       * @param {string|Array} sourceOrUrl Путь к файлу (например 'assets/data/tours.json') или массив объектов
       */
      loadCatalog: async function(sourceOrUrl){
        if(!sourceOrUrl) return null;

        try {
          let catalog = null;
          if(typeof sourceOrUrl === 'string'){
            const resp = await fetch(sourceOrUrl);
            if(!resp.ok) throw new Error('Не удалось загрузить каталог: ' + resp.status);
            catalog = await resp.json();
          } else if(Array.isArray(sourceOrUrl)){
            catalog = sourceOrUrl;
          }

          if(catalog && Array.isArray(catalog)){
            localStorage.setItem(STORAGE_TOURS_KEY, JSON.stringify(catalog));
            this.applyToDOM(catalog);
            return catalog;
          }
        } catch(err){
          console.warn('[Tourclick Sync] Ошибка синхронизации каталога:', err);
          if(window.reportError){
            window.reportError('Ошибка синхронизации каталога туров: ' + err.message, 'Tourclick.sync');
          }
        }
        return null;
      },

      /**
       * Применение полученных данных (цены, отели, фото) к HTML-элементам на странице
       */
      applyToDOM: function(catalog){
        if(!catalog || !catalog.length) return;

        // Поиск карточек туров на главной и в каталоге
        catalog.forEach(item => {
          if(!item.id) return;
          const links = document.querySelectorAll(`a[href*="id=${item.id}"]`);
          links.forEach(card => {
            // Обновление цены
            if(item.price){
              const priceEl = card.querySelector('.meta b, .price, [data-price]');
              if(priceEl) priceEl.textContent = item.price;
            }
            // Обновление описания / ночей
            if(item.nights){
              const nightsEl = card.querySelector('.meta span, [data-nights]');
              if(nightsEl) nightsEl.textContent = item.nights;
            }
            // Обновление фонового фото если передано
            if(item.photo){
              const cover = card.querySelector('.cover');
              if(cover) cover.style.backgroundImage = `url('${item.photo}')`;
            }
          });
        });
      },

      /**
       * Получить сохраненный каталог отелей
       */
      getCachedCatalog: function(){
        try {
          const raw = localStorage.getItem(STORAGE_TOURS_KEY);
          return raw ? JSON.parse(raw) : null;
        } catch(e){
          return null;
        }
      }
    }
  };

  // Авто-применение кэшированного каталога при открытии страницы
  window.addEventListener('DOMContentLoaded', function(){
    const cached = Tourclick.sync.getCachedCatalog();
    if(cached) Tourclick.sync.applyToDOM(cached);
  });

  window.Tourclick = Tourclick;
})();
