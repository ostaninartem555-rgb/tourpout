// Globe Study (Originkit) — портировано в ванильный JS для статичного билда.
// Оригинал: React-компонент. Здесь тот же canvas-рендер без React/сборки.
(function(){
  const MAX_DPR = 2;
  const FACE = '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif';
  const QA = Math.PI / 36;
  const MW = 288, MH = 144;

  const LAND_B64 =
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPcBAOD/HwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACA" +
    "//+P//f/LwgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4/v/4/////wcAAAAEAPABAAAAfAAAAAAAAAAAAAAAAAAAAADg9w/4" +
    "/////wEAAP4AAAAAAAAA+AAAAAAAAAAAAAAAAAAAAIAG+Of//////wAAAHwGAAAAAAAAAAMAAAAAAAAAAAAAAACABwAc/4P/////" +
    "/wAAADAAAAAAQAAAAD4AAAAAAAAAAAAAAAAAfMbDcQAA/v///wAAAAAAAADABwAA//8HAMAPAAAAAAAAAABgAAAAAAAA/P///wAA" +
    "AAAAAABwAADg//8AAAAAAAAAAAAAAADwG457dwcA8P//HwAAAAAAAAAYAAD///9/eAAAAAAAAAAAAAD4/g0H/w8A8P//PwAAAAAA" +
    "AAAOgOv/////fwD/AAAAAAA/AAAA/B84/v8A8P//LwAAAAD4AAAA4PP//////////wAAAOD///H/+D/3cPgDoP//DwAAAID/BwAA" +
    "x/v/////////P4AA/P///////////////////////w8AAOcBAAgAAAAAAAAAAAAAgP///////////////////////wcAACYAAAQA" +
    "AAAAAAAAAAAAgf///////////////////////wMM8AAAAAAAAAAAAAAAAAAAIID/////////e+wPwH8AgA8AAP/5z///////////" +
    "//////8/ANH///////9/AIALgD8AAAAAwH/+//////////////////9/APj///////8fADwAAD8AAAAA8D/+////////////////" +
    "//sPAPC/+f////8fAPwAADgAAAAA8D/+////////////////D/wBAMCfAP////8PAPwYAAAAAAAA8H/4//////////////9/DgcA" +
    "AAAcAOD///8/APw/AAAAAAAQAB7w//////////////8BgAMAAAACAMD/////Afh/AAAAAAA4gBz+/////////////38A4AMAAMAA" +
    "AMD/////B/z/AAAAAABwwAb+/////////////x8A8AEAAAAAAAD/////P///AwAAAADmgOH//////////////z8A4AAAAAAAAAD+" +
    "////P/7/BwAAAAD28P////////////////8D4AAAAAAAAAD8////f/7/BwAAAADz+f////////////////8HIAAAAAAAAAD6////" +
    "////BAAAAABw/v////////////////8EAAAAAAAAAADo//////8jHgAAAACA//////////////////8MAAAAAAAAAADQ//////8O" +
    "PgAAAADw//////////////////8AAAAAAAAAAADg//////+PIAAAAADA////v////////////38EAAAAAAAAAADg////////AAAA" +
    "AACA//v/zD/8/////////z8AAAAAAAAAAADg//////8bAAAAAACA//N/gD///////////x8GAAAAAAAAAADw//////8AAAAAAAD+" +
    "B8c/AD/+/////////wcPAAAAAAAAAADg//////8AAAAAAAD+gx4/DH74/////////wABAAAAAAAAAADg/////x8AAAAAAAD+gbCn" +
    "///8////////fQABAAAAAAAAAADg/////w8AAAAAAAD/gCDn///4//////9/MgADAAAAAAAAAADA/////w8AAAAAAAD+AADm/3/4" +
    "//////8/cIABAAAAAAAAAADA/////wcAAAAAAAA44AHC///5////////4+ABAAAAAAAAAACA/////wcAAAAAAACI/wEA4P//////" +
    "////4OgAAAAAAAAAAAAA/////wMAAAAAAAD4/wAA4P//////////ADYAAAAAAAAAAAAA/P///wEAAAAAAAD+/wEA8P//////////" +
    "AQcAAAAAAAAAAAAA+P//fwAAAAAAAAD//w8P8P//////////AQEAAAAAAAAAAAAAyP//fwAAAAAAAAD//3//////////////AQAA" +
    "AAAAAAAAAAAA0P+PYQAAAAAAAAD//////z//////////AwAAAAAAAAAAAAAAoP8HwAAAAAAAAMD/////83/+////////AQAAAAAA" +
    "AAAAAAAAIP8DwAAAAAAAAOD/////5//I////////AAAAAAAAAAAAAAAAQP4DgAAAAAAAAPD/////z/+A////////AAAAAAAAAAAA" +
    "AAAAAPwDAAIAAAAAAPD/////z/8ZwP////9/AQAAAAAAAAAAAAAAAPgDQAAAAAAAAPj/////j/9/gP////8fAQAAAAAAAAAAAAAA" +
    "APADEAMAAAAAAPz/////v///AP9//P8DAAAAAAAAAAAAAAAAAPADAwwAAAAAAPj/////P/9/APw//B8AAAAAAAAAAAAIAAAAAPCH" +
    "A8AAAAAAAPj/////P/4/APwP+J8BAAAAAAAAAAAAAAAAAMD/A0YEAAAAAPj/////f/4fAPwH+B8AAwAAAAAAAAAAAAAAAAD/AQAA" +
    "AAAAAPj/////f/wHAPgD8D8AAwAAAAAAAAAAAAAAAADgHwAAAAAAAPj///////wDAPgAwH8AAQAAAAAAAAAAAAAAAADAHwAAAAAA" +
    "APz//////30AAPAAwH8AAAAAAAAAAAAAAAAAAAAAHAAAAAAAAPj//////wsAAPAAgH4AAQAAAAAAAAAAAAAAAAAAGEAAAAAAAPj/" +
    "/////wMBAPAAgHwAAAAAAAAAAAAAAAAAAAAAGPAhAAAAAPD///////cBAOAAgDiABAAAAAAAAAAAAAAAAAAAIPl/AAAAAOD/////" +
    "//8AAGABABBAFAAAAAAAAAAAAAAAAAAAgP7/AQAAAMD///////8AAAABgAAAHAAAAAAAAAAAAAAAAAAAAPz/AQAAAID///////8A" +
    "AAABAAEgCAAAAAAAAAAAAAAAAAAAAPz/HwAAAAD/8P///38AAAAAAANgAAAAAAAAAAAAAAAAAAAAAPz/fwAAAAAAoP///z8AAAAA" +
    "YAd4AAAAAAAAAAAAAAAAAAAAAPz/fwAAAAAAAP///x8AAAAAwAY8AAAAAAAAAAAAAAAAAAAAAP7//wAAAAAAAP///w8AAAAAgAc+" +
    "AAAAAAAAAAAAAAAAAAAAAP///wAAAAAAAP///wcAAAAAgIM/TwAAAAAAAAAAAAAAAAAAAP///wEAAAAAgP///wMAAAAAAIc/QAQA" +
    "AAAAAAAAAAAAAAAAgP///w8AAAAAgP///wEAAAAAAA6fAUQAAAAAAAAAAAAAAAAAAP////8AAAAAAP///wAAAAAAAB6ewuwDAgAA" +
    "AAAAAAAAAAAAgP////8DAAAAAP7//wAAAAAAABwAAvAPAgAAAAAAAAAAAAAAgP////8PAAAAAPz/fwAAAAAAABAAAMCfAQAAAAAA" +
    "AAAAAAAAAP////8PAAAAAPz//wAAAAAAAOADAIA/MAAAAAAAAAAAAAAAAP7///8PAAAAAPz/fwAAAAAAAAAPAMBngAAAAAAAAAAA" +
    "AAAAAP7///8PAAAAAPz//wAAAAAAAAAACABAAAAAAAAAAAAAAAAAAPz///8HAAAAAPj//wAAAAAAAAAAAAAAAAIAAAAAAAAAAAAA" +
    "APz///8DAAAAAPj//wAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAPj///8BAAAAAPz//4AAAAAAAAAAAB8GAAAAAAAAAAAAAAAAAPj/" +
    "//8BAAAAAPz//8EAAAAAAAAAIB8OAAAAAAAAAAAAAAAAAPD///8BAAAAAP7//+AAAAAAAAAA+B8OACAAAAAAAAAAAAAAAMD///8B" +
    "AAAAAP7/f/gAAAAAAAAA/H8eAAAAAAAAAAAAAAAAAID///8AAAAAAP7/H/gAAAAAAAAA/P8fAABAAAAAAAAAAAAAAAD///8AAAAA" +
    "APz/D3AAAAAAAAAA/v8/AAAAAAAAAAAAAAAAAAD///8AAAAAAPj/D3gAAAAAAADA//9/AAgAAAAAAAAAAAAAAAD//38AAAAAAPj/" +
    "DzgAAAAAAADw////AAAAAAAAAAAAAAAAAAD//x8AAAAAAPD/DzgAAAAAAAD4////AQAAAAAAAAAAAAAAAAD//wMAAAAAAPD/DzgA" +
    "AAAAAAD4////AwAAAAAAAAAAAAAAAID//wEAAAAAAPD/AwAAAAAAAAD4////AwAAAAAAAAAAAAAAAID//wEAAAAAAPD/AwAAAAAA" +
    "AAD4////BwAAAAAAAAAAAAAAAID//wEAAAAAAOD/AwAAAAAAAAD4////BwAAAAAAAAAAAAAAAID//wAAAAAAAOD/AQAAAAAAAADw" +
    "////BwAAAAAAAAAAAAAAAID//wAAAAAAAMD/AAAAAAAAAADw////AwAAAAAAAAAAAAAAAID/fwAAAAAAAIB/AAAAAAAAAADgf/z/" +
    "AwAAAAAAAAAAAAAAAID/PwAAAAAAAIA/AAAAAAAAAADgB/D/AQAAAAAAAAAAAAAAAMD/HQAAAAAAAIABAAAAAAAAAADwAND/AQAA" +
    "AAAAAAAAAAAAAMD/AwAAAAAAAAAAAAAAAAAAAAAAAID/AAAIAAAAAAAAAAAAAMD/BwAAAAAAAAAAAAAAAAAAAAAAAAD/AAAQAAAA" +
    "AAAAAAAAAOD/AwAAAAAAAAAAAAAAAAAAAAAAAAA+AABwAAAAAAAAAAAAAOA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAA" +
    "AAAAAOA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAOAPAAAAAAAAAAAAAAAAAAAAAAAAAABwAAAGAAAAAAAAAAAA" +
    "AMAPAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAADAAAAAAAAAAAAAPAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMABAAAAAAAAAAAAAPAD" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAOABAAAAAAAAAAAAAPAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPAHAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPADAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAPABAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPCBAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGABAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAA" +
    "AAAAAAAAAAAAAAAcAAAAAAAAAAAAAAA+AABAAJ8//j8PAAAAAAAAAAAAAAAAAAAMAAAAAAAAAAAAAPD/fwD///////8/AAAAAAAA" +
    "AAAAAAAAAIA+AAAAAAAAAAAAPP///8D/////////HwAAAAAAAAAAAAAAAIA9AAAAAAAA8Pz/////P/j//////////wMAAAAAAAAA" +
    "AMAAAPB9AAAAAID/////////P/7///////////8BAAAAAAAAAOABAwB/AAAAAPD///////////////////////8AAAAAAFACPoD/" +
    "//9/AAAAAPD//////////////////////x8AAAAA+P////////8HAAAAAP///////////////////////wcAAAAA/v///////wMA" +
    "AAAA/v///////////////////////wcAAAD8/////////w8AAA7w/////////////////////////w8AAMAB/////////wMAgB84" +
    "/////////////////////////wEAAAAA/P///////3/w4AcA/////////////////////////wAAAADg//////////8/gM//////" +
    "/////////////////////wMAAADg/////////////f///////////////////////////z8A7wMA/v//////////////////////" +
    "//////////////////8/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAA";

  function num(v, fb){ return (typeof v === "number" && isFinite(v)) ? v : fb; }
  function clampN(v, lo, hi){ return v < lo ? lo : v > hi ? hi : v; }
  function parseRGB(input, fb){
    if(!input) return fb;
    const str = String(input).trim();
    if(str.charAt(0) === "#"){
      let hex = str.slice(1);
      if(hex.length === 3 || hex.length === 4) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
      if(hex.length >= 6){
        const r = parseInt(hex.slice(0,2),16), g = parseInt(hex.slice(2,4),16), b = parseInt(hex.slice(4,6),16);
        if(!isNaN(r) && !isNaN(g) && !isNaN(b)) return [r,g,b];
      }
      return fb;
    }
    const m = str.match(/[\d.]+/g);
    if(m && m.length >= 3) return [+m[0], +m[1], +m[2]];
    return fb;
  }

  window.initGlobeStudy = function(canvas, opts){
    opts = opts || {};
    const o = {
      baseColor: opts.baseColor || "#E2E4E9",
      phrase: (typeof opts.phrase === "string" && opts.phrase.length) ? opts.phrase : "everypointonthisballisapathbacktoanotherone",
      density: clampN(num(opts.density, 53), 40, 200) / 100,
      glyphSize: clampN(num(opts.glyphSize, 90), 20, 300) / 100,
      speed: clampN(num(opts.speed, 100), 0, 100) / 50,
      hover: clampN(num(opts.hover, 100), 0, 200) / 100,
      radius: clampN(num(opts.radius, 100), 40, 200) / 100,
      drift: clampN(num(opts.drift, 210), 0, 400) / 100,
      letters: clampN(num(opts.letters, 100), 0, 200) / 100,
      zoomK: clampN(num(opts.zoom, 100), 0, 300) / 100,
      light: clampN(num(opts.light, 100), 0, 300) / 100,
      pins: Math.round(clampN(num(opts.pins, 7), 0, 24))
    };
    const ctx = canvas.getContext("2d");
    if(!ctx) return function(){};

    let land = null;
    try{
      const bin = atob(LAND_B64);
      land = new Uint8Array(bin.length);
      for(let i=0;i<bin.length;i++) land[i] = bin.charCodeAt(i);
    }catch(e){ land = null; }
    const isLand = (lon, lat) => {
      if(!land) return false;
      const gx = Math.floor(((lon+180)/360)*MW);
      const gy = Math.floor(((90-lat)/180)*MH);
      if(gx<0||gx>=MW||gy<0||gy>=MH) return false;
      const b = gy*MW+gx;
      return ((land[b>>3] >> (b&7)) & 1) === 1;
    };

    let nodes = [];
    let builtKey = "";
    const build = (dens, letterK, text) => {
      const step = 3.05 / dens;
      nodes = [];
      let k = 0, run = 0, sea3 = 0;
      const every = letterK <= 0 ? 0 : Math.max(1, Math.round(2/letterK));
      for(let lat=-86; lat<=86; lat+=step){
        const rl = Math.cos((lat*Math.PI)/180);
        const n = Math.max(1, Math.round(98*dens*rl));
        for(let i=0;i<n;i++){
          const lon = -180 + (360*i)/n;
          const l = isLand(lon, lat);
          if(!l && sea3++ % 2) continue;
          let letter = "";
          if(l && every && run++ % every === 0) letter = text.charAt(k++ % text.length);
          nodes.push({lat:(lat*Math.PI)/180, lon:(lon*Math.PI)/180, land:l, c:letter});
        }
      }
      builtKey = dens+"|"+letterK+"|"+text;
    };

    const pins = [];
    const view = {cx:0, cy:0, R:1, cs:1, sn:0, ct:1, st:0};
    const unproject = (px, py) => {
      const x1 = (px-view.cx)/view.R;
      const y2 = (view.cy-py)/view.R;
      const q = 1 - x1*x1 - y2*y2;
      if(q <= 0.002) return null;
      const z2 = Math.sqrt(q);
      const y0 = y2*view.ct + z2*view.st;
      const z1 = -y2*view.st + z2*view.ct;
      const x0 = x1*view.cs + z1*view.sn;
      const z0 = -x1*view.sn + z1*view.cs;
      return {lat: Math.asin(clampN(y0,-1,1)), lon: Math.atan2(z0,x0)};
    };

    const ptr = {on:0, x:-1e9, y:-1e9, dragging:0, dx:0, dy:0, moved:0, click:0};
    let raf = 0, last = performance.now(), clock = 0;
    let spin = 2.1, vel = 0.16, tilt = -0.36, vtilt = 0, zoom = 1, zoomT = 1, seenClick = 0;
    const sea = [], soil = [], land8 = [];

    const render = (now) => {
      const dt = Math.min(0.05, (now-last)/1000);
      last = now;
      clock += dt * o.speed;
      const dpr = Math.min(window.devicePixelRatio || 1, MAX_DPR);
      const cw = canvas.clientWidth || 800;
      const ch = canvas.clientHeight || 560;
      const bw = Math.max(1, Math.round(cw*dpr)), bh = Math.max(1, Math.round(ch*dpr));
      if(canvas.width !== bw || canvas.height !== bh){ canvas.width = bw; canvas.height = bh; }
      ctx.setTransform(dpr,0,0,dpr,0,0);
      ctx.clearRect(0,0,cw,ch);

      const key = o.density+"|"+o.letters+"|"+o.phrase;
      if(key !== builtKey) build(o.density, o.letters, o.phrase);

      const u = Math.min(cw, ch);
      const hv = o.hover * (ptr.on ? 1 : 0);
      zoom += (zoomT-zoom) * Math.min(1, dt/0.18);

      const cx = cw/2, cy = ch/2 + u*0.035;
      const R = u*0.318*zoom*o.radius;
      const fs = u*0.0275*Math.pow(zoom,0.72)*o.glyphSize;

      if(ptr.dragging){
        const dspin = (ptr.dx*u)/R, dtilt = (-ptr.dy*u)/R;
        ptr.dx = 0; ptr.dy = 0;
        spin += dspin;
        tilt = clampN(tilt+dtilt, -1.15, 1.15);
        const k = Math.min(1, dt/0.07), inv = 1/Math.max(dt, 1/240);
        vel += (clampN(dspin*inv,-9,9)-vel)*k;
        vtilt += (clampN(dtilt*inv,-9,9)-vtilt)*k;
      } else {
        const idle = 0.16*o.drift*(hv>0 ? 0.28 : 1);
        vel += (idle-vel)*Math.min(1,(dt*o.speed)/0.9);
        vtilt *= Math.exp(-dt*o.speed*6.6);
        tilt = clampN(tilt+vtilt*dt*o.speed, -1.15, 1.15);
        tilt += (-0.36-tilt)*Math.min(1,(dt*o.speed)/4);
        spin += vel*dt*o.speed;
      }

      if(ptr.click !== seenClick){
        seenClick = ptr.click;
        const g = unproject(ptr.x, ptr.y);
        if(g && o.pins > 0){ pins.push({lat:g.lat, lon:g.lon, t:clock}); while(pins.length > o.pins) pins.shift(); }
      }

      const cs = Math.cos(spin), sn = Math.sin(spin), ct = Math.cos(tilt), st = Math.sin(tilt);
      view.cx=cx; view.cy=cy; view.R=R; view.cs=cs; view.sn=sn; view.ct=ct; view.st=st;

      const lightK = o.light*hv;
      const lx = lightK>0 && !ptr.dragging ? ptr.x : -1e9;
      const ly = lightK>0 && !ptr.dragging ? ptr.y : -1e9;
      const lr = u*0.2, lr2 = lr*lr;

      const ink = parseRGB(o.baseColor, [226,228,233]);
      const rgb = ink[0]+","+ink[1]+","+ink[2];
      const tone = (a) => "rgba("+rgb+","+clampN(a,0,1).toFixed(3)+")";

      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      sea.length = 0; soil.length = 0;
      for(let bi=0;bi<8;bi++) if(land8[bi]) land8[bi].length = 0;

      for(let i=0;i<nodes.length;i++){
        const nd = nodes[i];
        const cl = Math.cos(nd.lat);
        const x0 = cl*Math.cos(nd.lon), y0 = Math.sin(nd.lat), z0 = cl*Math.sin(nd.lon);
        const x1 = x0*cs - z0*sn, z1 = x0*sn + z0*cs;
        const y2 = y0*ct - z1*st, z2 = y0*st + z1*ct;
        if(z2 <= 0.02) continue;
        const px = cx + x1*R, py = cy - y2*R;
        const ddx = px-lx, ddy = py-ly;
        const glow = ddx*ddx+ddy*ddy < lr2 ? (1-Math.sqrt(ddx*ddx+ddy*ddy)/lr)*lightK : 0;
        if(!nd.land){ sea.push(px,py,Math.min(0.999,z2+glow*0.55)); continue; }
        if(!nd.c){ soil.push(px,py,Math.min(0.999,z2+glow*0.55)); continue; }
        const tx0 = -Math.sin(nd.lon), tz0 = Math.cos(nd.lon);
        const tx1 = tx0*cs - tz0*sn, tz1 = tx0*sn + tz0*cs;
        const ang = Math.round(Math.atan2(tz1*st,tx1)/QA)*QA;
        const b = Math.min(7, Math.max(0,(Math.min(0.999,z2+glow*0.6)*7.99)|0));
        (land8[b] || (land8[b]=[])).push(px,py,ang,i);
      }

      const dmin = Math.max(0.7, u*0.0029);
      const dots = (list, baseA, gain, grow) => {
        for(let lvl=0; lvl<6; lvl++){
          const z = (lvl+0.5)/6;
          const dsz = dmin*grow*(0.55+0.75*z);
          ctx.fillStyle = tone(baseA+gain*z);
          ctx.beginPath();
          for(let q=0;q<list.length;q+=3){
            const lv = list[q+2] >= 1 ? 5 : (list[q+2]*6)|0;
            if(lv !== lvl) continue;
            ctx.rect(list[q]-dsz/2, list[q+1]-dsz/2, dsz, dsz);
          }
          ctx.fill();
        }
      };
      dots(sea, 0.1, 0.22, 1.0);
      dots(soil, 0.34, 0.46, 1.7);

      for(let bi=0;bi<8;bi++){
        const arr = land8[bi];
        if(!arr || !arr.length) continue;
        const zb = (bi+0.5)/8;
        ctx.font = "bold "+(fs*(0.42+0.58*zb)).toFixed(2)+"px "+FACE;
        ctx.fillStyle = tone(0.28+0.72*Math.pow(zb,0.6));
        for(let t=0;t<arr.length;t+=4){
          ctx.save(); ctx.translate(arr[t],arr[t+1]); ctx.rotate(arr[t+2]);
          ctx.fillText(nodes[arr[t+3]].c,0,0);
          ctx.restore();
        }
      }

      for(let pi=0;pi<pins.length;pi++){
        const pn = pins[pi];
        const pcl = Math.cos(pn.lat);
        const ax = pcl*Math.cos(pn.lon), ay = Math.sin(pn.lat), az = pcl*Math.sin(pn.lon);
        const bx1 = ax*cs - az*sn, bz1 = ax*sn + az*cs;
        const by2 = ay*ct - bz1*st, bz2 = ay*st + bz1*ct;
        if(bz2 <= 0.02) continue;
        const ppx = cx+bx1*R, ppy = cy-by2*R;
        const age = clock-pn.t, pop = Math.min(1, age/0.22);
        const rr2 = u*0.016*(0.4+0.6*pop)*(0.55+0.45*bz2);
        ctx.beginPath(); ctx.arc(ppx,ppy,rr2,0,Math.PI*2);
        ctx.strokeStyle = tone(0.3+0.55*bz2); ctx.lineWidth = Math.max(0.7,u*0.0022); ctx.stroke();
        ctx.beginPath(); ctx.arc(ppx,ppy,Math.max(0.7,rr2*0.22),0,Math.PI*2);
        ctx.fillStyle = tone(0.45+0.55*bz2); ctx.fill();
        if(age < 0.9){
          const w2 = 1-age/0.9;
          ctx.beginPath(); ctx.arc(ppx,ppy,rr2+(1-w2)*u*0.05,0,Math.PI*2);
          ctx.strokeStyle = tone(0.55*w2*w2); ctx.lineWidth = Math.max(0.6,u*0.0016); ctx.stroke();
        }
      }
      raf = requestAnimationFrame(render);
    };

    let lastX = 0, lastY = 0;
    const localPoint = (e) => {
      const r = canvas.getBoundingClientRect();
      if(r.width<=0||r.height<=0) return null;
      const cw = canvas.clientWidth||800, ch = canvas.clientHeight||560;
      return {x:((e.clientX-r.left)/r.width)*cw, y:((e.clientY-r.top)/r.height)*ch};
    };
    const track = (e) => {
      const p = localPoint(e); if(!p) return;
      ptr.on = 1;
      if(ptr.dragging){
        const u = Math.min(canvas.clientWidth||800, canvas.clientHeight||560);
        ptr.dx += (p.x-lastX)/u; ptr.dy += (p.y-lastY)/u; ptr.moved = 1;
      }
      ptr.x = p.x; ptr.y = p.y; lastX = p.x; lastY = p.y;
    };
    const onDown = (e) => {
      const p = localPoint(e); if(!p) return;
      ptr.dragging = 1; ptr.moved = 0; ptr.x = p.x; ptr.y = p.y; lastX = p.x; lastY = p.y;
      try{ canvas.setPointerCapture(e.pointerId); }catch(err){}
    };
    const onUp = () => { if(ptr.dragging && !ptr.moved) ptr.click++; ptr.dragging = 0; };
    const onLeave = () => { if(!ptr.dragging) ptr.on = 0; };
    const onWheel = (e) => {
      if(o.zoomK <= 0) return;
      e.preventDefault();
      zoomT = clampN(zoomT*Math.exp(-e.deltaY*0.0016*o.zoomK), 0.85, 2.6);
    };

    canvas.addEventListener("pointermove", track);
    canvas.addEventListener("pointerenter", track);
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    canvas.addEventListener("wheel", onWheel, {passive:false});
    raf = requestAnimationFrame(render);

    return function(){
      cancelAnimationFrame(raf);
      canvas.removeEventListener("pointermove", track);
      canvas.removeEventListener("pointerenter", track);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      canvas.removeEventListener("wheel", onWheel);
    };
  };
})();
