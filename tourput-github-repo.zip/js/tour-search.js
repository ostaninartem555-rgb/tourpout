/**
 * ТУР ПУТЬ — Модуль интерактивного поиска туров (Tour Search Engine)
 * Архитектура Tourclick Ready: подготовлена к бесшовному подключению внешнего
 * модуля Турклика (цены, туры, отели), сохраняя премиальный визуальный стиль.
 */
(function(window, document) {
  'use strict';

  // База туров по умолчанию (нативные данные до передачи модуля Турклика)
  const MOCK_TOURS_DATABASE = [
    {
      id: 'spb-classic',
      title: 'Классический Петербург & Дворцы Эрмитажа',
      direction: 'spb',
      directionName: 'Санкт-Петербург',
      from: 'msk',
      fromName: 'Москва',
      type: 'tours',
      category: 'Экскурсионный тур',
      hotel: 'Отель Октябрьская 4★ (Лиговский пр.)',
      stars: 4,
      nights: 4,
      days: 5,
      date: '24.10.2026',
      price: 24500,
      oldPrice: 28900,
      agencyCommission: 3185, // 13%
      instantConfirm: true,
      badge: 'Хит сезона',
      badgeClass: 'hit',
      imgGrad: 'linear-gradient(135deg, #1e293b, #3b82f6)',
      features: ['Завтраки Шведский стол', 'Билеты в Эрмитаж и Царское Село', 'Комфортабельный автобус']
    },
    {
      id: 'spb-weekend',
      title: 'Петербургские выходные: Разводные мосты и Нева',
      direction: 'spb',
      directionName: 'Санкт-Петербург',
      from: 'all',
      fromName: 'На месте (СПб)',
      type: 'tours',
      category: 'Weekend тур',
      hotel: 'Cosmos St. Petersburg Nevsky Hotel 4★',
      stars: 4,
      nights: 2,
      days: 3,
      date: '25.10.2026',
      price: 18900,
      oldPrice: 21500,
      agencyCommission: 2457,
      instantConfirm: true,
      badge: 'Уикенд',
      badgeClass: 'weekend',
      imgGrad: 'linear-gradient(135deg, #0f172a, #6366f1)',
      features: ['Ночная прогулка на теплоходе', 'Пешеходная с гидом по крышам', 'Центр города']
    },
    {
      id: 'altai-golden',
      title: 'Золотой Алтай: Чуйский тракт, Катунь и Гейзерное озеро',
      direction: 'altai',
      directionName: 'Горный Алтай',
      from: 'msk',
      fromName: 'Москва (авиа)',
      type: 'tours',
      category: 'Авторский тур',
      hotel: 'Эко-курорт Марьин Остров 4★ / Кедровые коттеджи',
      stars: 4,
      nights: 6,
      days: 7,
      date: '28.10.2026',
      price: 52000,
      oldPrice: 59000,
      agencyCommission: 6760,
      instantConfirm: true,
      badge: 'Премиум',
      badgeClass: 'premium',
      imgGrad: 'linear-gradient(135deg, #064e3b, #059669)',
      features: ['Трансфер на джипах 4x4', '3-разовое алтайское питание', 'Русская баня на горной реке']
    },
    {
      id: 'baikal-ice',
      title: 'Легендарный Байкал: Ольхон, торосы и ледяные гроты',
      direction: 'baikal',
      directionName: 'Озеро Байкал',
      from: 'msk',
      fromName: 'Москва (авиа)',
      type: 'tours',
      category: 'Зимняя сказка',
      hotel: 'Baikal View Hotel 3★ / Усадьба Набаймар',
      stars: 3,
      nights: 5,
      days: 6,
      date: '15.11.2026',
      price: 54900,
      oldPrice: 62000,
      agencyCommission: 7137,
      instantConfirm: false,
      badge: 'Топ продаж',
      badgeClass: 'hit',
      imgGrad: 'linear-gradient(135deg, #0c4a6e, #0284c7)',
      features: ['Хивус (катер на воздушной подушке)', 'Мыс Бурхан и скала Шаманка', 'Байкальский омуль']
    },
    {
      id: 'sochi-polyana',
      title: 'Сочи & Красная Поляна: Море, Горы и Олимпик Парк',
      direction: 'sochi',
      directionName: 'Сочи',
      from: 'msk',
      fromName: 'Москва',
      type: 'tours',
      category: 'Комбинированный тур',
      hotel: 'Radisson Hotel Rosa Khutor 5★ / Сочи Центр 4★',
      stars: 5,
      nights: 7,
      days: 8,
      date: '30.10.2026',
      price: 42000,
      oldPrice: 47500,
      agencyCommission: 5460,
      instantConfirm: true,
      badge: 'All Inclusive',
      badgeClass: 'weekend',
      imgGrad: 'linear-gradient(135deg, #0369a1, #0ea5e9)',
      features: ['Подъемники на Роза Пик', 'Термальный спа-бассейн с видом на горы', 'Трансфер к морю']
    },
    {
      id: 'kazan-orient',
      title: 'Сокровища Татарстана: Белокаменный Кремль и Свияжск',
      direction: 'kazan',
      directionName: 'Казань',
      from: 'spb',
      fromName: 'Санкт-Петербург',
      type: 'tours',
      category: 'Культурно-гастрономический',
      hotel: 'Гранд Отель Казань 4★ (ул. Баумана)',
      stars: 4,
      nights: 3,
      days: 4,
      date: '02.11.2026',
      price: 23500,
      oldPrice: 26800,
      agencyCommission: 3055,
      instantConfirm: true,
      badge: 'Гастро-тур',
      badgeClass: 'hit',
      imgGrad: 'linear-gradient(135deg, #581c87, #a855f7)',
      features: ['Мастер-класс татарской кухни', 'Кул-Шариф и Дворец Земледельцев', 'Остров Свияжск']
    },
    {
      id: 'kmv-health',
      title: 'Кавказские Минеральные Воды: Здоровье, Нарзаны и Эльбрус',
      direction: 'kmv',
      directionName: 'КМВ',
      from: 'msk',
      fromName: 'Москва',
      type: 'tours',
      category: 'Оздоровительный тур',
      hotel: 'Санаторий Плаза 4★ / Родник Кисловодск',
      stars: 4,
      nights: 7,
      days: 8,
      date: '05.11.2026',
      price: 32000,
      oldPrice: 36000,
      agencyCommission: 4160,
      instantConfirm: true,
      badge: 'Санатории',
      badgeClass: 'premium',
      imgGrad: 'linear-gradient(135deg, #78350f, #d97706)',
      features: ['Курс нарзанных ванн и СПА', 'Экскурсия на поляну Азау (Эльбрус)', 'Курортный парк Кисловодска']
    },
    {
      id: 'karelia-ruskeala',
      title: 'Карельская сказка: Мраморный каньон Рускеала и водопады',
      direction: 'spb',
      directionName: 'Карелия & Приладожье',
      from: 'spb',
      fromName: 'Санкт-Петербург',
      type: 'tours',
      category: 'Экскурсионный экспресс',
      hotel: 'Отель Сеурахуоне 3★ (Сортавала)',
      stars: 3,
      nights: 2,
      days: 3,
      date: '26.10.2026',
      price: 15400,
      oldPrice: 17800,
      agencyCommission: 2002,
      instantConfirm: true,
      badge: 'Хит',
      badgeClass: 'hit',
      imgGrad: 'linear-gradient(135deg, #14532d, #16a34a)',
      features: ['Ретропоезд Рускеальский экспресс', 'Ладожские шхеры на катере', 'Карельская уха лохикейтто']
    }
  ];

  // Global state
  const state = {
    activeTab: 'tours', // 'tours', 'excursions', 'hotels', 'school', 'cruises', 'byname'
    from: 'all',
    direction: 'all',
    dateRange: 'any',
    nights: 'any',
    adults: 2,
    children: 0,
    hotelStars: 'all',
    instantOnly: false,
    audienceMode: 'tourists', // 'tourists' | 'agencies'
    tourclickReady: false
  };

  // Helper format price
  function formatRub(n) {
    return (n || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " ₽";
  }

  // Tourclick Bridge API: для будущей загрузки данных из внешнего модуля Турклик
  window.TourclickSearchBridge = {
    isReady: false,
    version: '2.0-ext-ready',
    setDataSource: function(externalModule) {
      if (externalModule && typeof externalModule.searchTours === 'function') {
        window.TourclickSearchBridge.external = externalModule;
        window.TourclickSearchBridge.isReady = true;
        console.log('[TourclickBridge] Внешний модуль Турклик успешно зарегистрирован!');
      }
    },
    triggerSearch: function(params) {
      if (window.TourclickSearchBridge.isReady && window.TourclickSearchBridge.external) {
        return window.TourclickSearchBridge.external.searchTours(params);
      }
      return filterMockTours(params);
    }
  };

  // Filter local mock tours
  function filterMockTours(filters) {
    return MOCK_TOURS_DATABASE.filter(t => {
      if (filters.direction && filters.direction !== 'all' && t.direction !== filters.direction) {
        return false;
      }
      if (filters.from && filters.from !== 'all' && t.from !== 'all' && t.from !== filters.from) {
        return false;
      }
      if (filters.hotelStars && filters.hotelStars !== 'all' && t.stars < parseInt(filters.hotelStars, 10)) {
        return false;
      }
      if (filters.instantOnly && !t.instantConfirm) {
        return false;
      }
      return true;
    });
  }

  // Render results
  function renderResults(tours) {
    const container = document.getElementById('searchResultsGrid');
    const countEl = document.getElementById('searchCountBadge');
    if (!container) return;

    if (countEl) {
      countEl.textContent = 'Найдено туров: ' + tours.length;
    }

    if (tours.length === 0) {
      container.innerHTML = `
        <div class="search-empty-state">
          <div style="font-size:42px;margin-bottom:10px">🔍</div>
          <h3 style="font-size:18px;margin-bottom:6px">По выбранным параметрам туры не найдены</h3>
          <p style="color:var(--muted);font-size:14px;max-width:440px;margin:0 auto 16px">Попробуйте выбрать «Любое направление» или сбросить фильтры звездности, либо свяжитесь с менеджером — мы подберем индивидуальную программу.</p>
          <button class="btn ghost" id="btnResetSearchFilters" type="button" style="font-size:13px;padding:8px 16px">Сбросить фильтры</button>
        </div>
      `;
      const btnReset = document.getElementById('btnResetSearchFilters');
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          const dirSel = document.getElementById('tsDirection');
          const fromSel = document.getElementById('tsFrom');
          if (dirSel) dirSel.value = 'all';
          if (fromSel) fromSel.value = 'all';
          state.direction = 'all';
          state.from = 'all';
          state.hotelStars = 'all';
          renderResults(MOCK_TOURS_DATABASE);
        });
      }
      return;
    }

    const isAgency = (state.audienceMode === 'agencies');

    container.innerHTML = tours.map(t => {
      const b2bBadge = isAgency ? `
        <div class="search-card-b2b">
          <span>Комиссия ТА: <b>13%</b> (${formatRub(t.agencyCommission)})</span>
          <span class="b2b-sub">К оплате туроператору: <b>${formatRub(t.price - t.agencyCommission)}</b></span>
        </div>
      ` : '';

      const starIcons = '★'.repeat(t.stars || 4);

      return `
        <article class="search-card" data-tour-id="${t.id}">
          <div class="search-card-cover" style="background:${t.imgGrad}">
            <div class="search-card-top-tags">
              <span class="search-badge ${t.badgeClass}">${t.badge}</span>
              ${t.instantConfirm ? '<span class="search-badge instant">Мгновенное подтверждение</span>' : ''}
            </div>
            <div class="search-card-title-wrap">
              <span class="search-card-dir">${t.directionName} • ${t.category}</span>
              <h4>${t.title}</h4>
            </div>
          </div>
          <div class="search-card-body">
            <div class="search-card-hotel">
              <span style="color:#f59e0b;letter-spacing:1px">${starIcons}</span>
              <span class="hotel-name">${t.hotel}</span>
            </div>
            <div class="search-card-details">
              <span>Вылет: <b>${t.date}</b></span>
              <span>•</span>
              <span><b>${t.nights} ночей</b> (${t.days} дн.)</span>
              <span>•</span>
              <span>Из: <b>${t.fromName}</b></span>
            </div>
            <div style="font-size:11.5px;color:var(--muted);background:var(--bg2);padding:6px 10px;border-radius:4px;border:1px solid var(--line);display:flex;align-items:center;gap:6px">
              <span>✈️ Прямой рейс • Багаж 20 кг включен • Трансфер и страховка</span>
            </div>
            <ul class="search-card-features">
              ${t.features.map(f => `<li>✓ ${f}</li>`).join('')}
            </ul>
            ${b2bBadge}
            <div class="search-card-footer">
              <div class="search-price-wrap">
                <span class="price-from">${isAgency ? 'Розничная цена (за двоих):' : 'Цена за двоих с перелетом:'}</span>
                <div class="price-val">
                  <b>${formatRub(t.price)}</b>
                  <s class="price-old">${formatRub(t.oldPrice)}</s>
                </div>
              </div>
              <button class="btn btn-book-tour" type="button" data-title="${t.title}" data-price="${t.price}" data-dir="${t.directionName}">
                ${isAgency ? 'Забронировать (B2B)' : 'Выбрать тур'}
              </button>
            </div>
          </div>
        </article>
      `;
    }).join('');

    // Wire booking buttons & entire search-card click to lead modal / widget
    container.querySelectorAll('.search-card').forEach(card => {
      card.addEventListener('click', function(e) {
        e.preventDefault();
        const btn = this.querySelector('.btn-book-tour');
        const tourTitle = (btn && btn.getAttribute('data-title')) || this.querySelector('h4')?.textContent || 'Выбранный тур';
        const tourPrice = (btn && btn.getAttribute('data-price')) || '';
        const tourDir = (btn && btn.getAttribute('data-dir')) || '';

        // If on preview/SPA, navigate or open modal
        if (typeof window.openTourModal === 'function') {
          window.openTourModal(tourTitle, tourPrice, tourDir, { isAgency: isAgency });
        } else {
          // Pre-populate widget storage and redirect or prompt
          try {
            sessionStorage.setItem('selected_tour_name', tourTitle);
            sessionStorage.setItem('selected_tour_price', tourPrice);
          } catch(err){}

          const targetUrl = isAgency ? 'agency.html#lead' : 'widget.html?tour=' + encodeURIComponent(tourTitle);
          if (window.location.pathname.indexOf('preview.html') >= 0 || window.location.pathname.indexOf('_preview.html') >= 0) {
            // In SPA preview, trigger route
            const navLink = document.querySelector(`a[data-route="${isAgency ? 'agency' : 'widget'}"]`);
            if (navLink) {
              navLink.click();
            } else {
              window.location.href = targetUrl;
            }
          } else {
            window.location.href = targetUrl;
          }
        }
      });
    });
  }

  // Initialize Search Widget UI
  function initTourSearch() {
    const searchRoot = document.getElementById('tourSearchEngine');
    if (!searchRoot) return;

    // 1. Audience Selector (Туристам / Агентствам)
    const audienceTabs = searchRoot.querySelectorAll('.audience-tab, [data-audience]');
    audienceTabs.forEach(tab => {
      tab.addEventListener('click', function(e) {
        e.preventDefault();
        const aud = this.getAttribute('data-audience') || 'tourists';
        setAudienceMode(aud);
      });
    });

    // Check localStorage for saved audience
    try {
      const savedAud = localStorage.getItem('tourput_audience_mode');
      if (savedAud === 'agencies' || savedAud === 'tourists') {
        setAudienceMode(savedAud);
      }
    } catch(e){}

    // 2. Search category tabs (Туры, Экскурсии, Отели, Школьные, Круизы)
    const catTabs = searchRoot.querySelectorAll('.ts-tab-btn');
    catTabs.forEach(btn => {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        catTabs.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        state.activeTab = this.getAttribute('data-tab') || 'tours';
        doSearch();
      });
    });

    // 3. Закрытие всех открытых пикеров
    function closeAllPickers() {
      document.querySelectorAll('.ts-picker-panel.show').forEach(p => p.classList.remove('show'));
      document.querySelectorAll('.ts-custom-trigger.open').forEach(t => {
        t.classList.remove('open');
        t.setAttribute('aria-expanded', 'false');
      });
      const tDrop = document.getElementById('tsTouristsDropdown');
      if (tDrop) tDrop.classList.remove('show');
    }

    // Универсальный обработчик кастомных пикеров (Откуда, Куда, Даты, Ночи)
    function bindCustomPicker(triggerId, panelId, hiddenInputId, onSelectCallback) {
      const trigger = document.getElementById(triggerId);
      const panel = document.getElementById(panelId);
      const hidden = document.getElementById(hiddenInputId);
      if (!trigger || !panel) return;

      trigger.addEventListener('click', function(e) {
        e.stopPropagation();
        const isOpen = panel.classList.contains('show');
        closeAllPickers();
        if (!isOpen) {
          panel.classList.add('show');
          trigger.classList.add('open');
          trigger.setAttribute('aria-expanded', 'true');
          const searchInput = panel.querySelector('.ts-picker-search');
          if (searchInput) {
            setTimeout(() => searchInput.focus(), 80);
          }
        }
      });

      panel.addEventListener('click', function(e) {
        e.stopPropagation();
      });

      // Выбор элемента из списка пикера
      panel.querySelectorAll('.ts-picker-item, .ts-dir-item').forEach(item => {
        item.addEventListener('click', function(e) {
          e.stopPropagation();
          const val = this.getAttribute('data-val');
          const name = this.getAttribute('data-name');
          const sub = this.getAttribute('data-sub');
          const icon = this.getAttribute('data-icon');

          if (hidden) hidden.value = val;

          // Обновление текстовых полей кнопки-триггера
          const valTextEl = trigger.querySelector('.ts-trigger-val');
          const subTextEl = trigger.querySelector('.ts-trigger-sub');
          const iconEl = trigger.querySelector('.ts-trigger-icon');

          if (valTextEl && name) valTextEl.textContent = name;
          if (subTextEl && sub) subTextEl.textContent = sub;
          if (iconEl && icon) iconEl.textContent = icon;

          // Подсветка активного пункта
          panel.querySelectorAll('.ts-picker-item, .ts-dir-item').forEach(i => i.classList.remove('active'));
          this.classList.add('active');

          closeAllPickers();

          if (typeof onSelectCallback === 'function') {
            onSelectCallback(val, name);
          }
        });
      });
    }

    // Привязка пикера "Откуда"
    bindCustomPicker('tsFromTrigger', 'tsFromPicker', 'tsFrom', (val) => {
      state.from = val;
      doSearch();
    });

    // Живой поиск по городам отправления
    const fromSearchInput = document.getElementById('tsFromSearch');
    if (fromSearchInput) {
      fromSearchInput.addEventListener('input', function() {
        const q = this.value.trim().toLowerCase();
        document.querySelectorAll('#tsFromList .ts-picker-item').forEach(item => {
          const text = (item.getAttribute('data-name') || '') + ' ' + (item.getAttribute('data-sub') || '') + ' ' + item.textContent;
          item.style.display = text.toLowerCase().includes(q) ? 'flex' : 'none';
        });
      });
    }

    // Быстрые теги городов внутри пикера "Откуда"
    document.querySelectorAll('[data-select-from]').forEach(btn => {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        const targetVal = this.getAttribute('data-select-from');
        const targetItem = document.querySelector(`#tsFromList .ts-picker-item[data-val="${targetVal}"]`);
        if (targetItem) targetItem.click();
      });
    });

    // Привязка пикера "Куда отправимся"
    bindCustomPicker('tsDirTrigger', 'tsDirPicker', 'tsDirection', (val) => {
      state.direction = val;
      // Синхронизация быстрых чипсов внизу поисковика
      document.querySelectorAll('.ts-quick-chip').forEach(chip => {
        chip.classList.toggle('active', chip.getAttribute('data-dir') === val);
      });
      doSearch();
    });

    // Живой поиск по курортам и регионам внутри пикера "Куда"
    const dirSearchInput = document.getElementById('tsDirSearch');
    if (dirSearchInput) {
      dirSearchInput.addEventListener('input', function() {
        const q = this.value.trim().toLowerCase();
        document.querySelectorAll('#tsDirList .ts-dir-item').forEach(item => {
          const text = (item.getAttribute('data-name') || '') + ' ' + (item.getAttribute('data-sub') || '') + ' ' + item.textContent;
          item.style.display = text.toLowerCase().includes(q) ? 'flex' : 'none';
        });
      });
    }

    // Фильтрация направлений по категориям (Горы, Море, Города, Санатории)
    document.querySelectorAll('.ts-dir-chip').forEach(chip => {
      chip.addEventListener('click', function(e) {
        e.stopPropagation();
        document.querySelectorAll('.ts-dir-chip').forEach(c => c.classList.remove('active'));
        this.classList.add('active');
        const cat = this.getAttribute('data-dir-cat');
        document.querySelectorAll('#tsDirList .ts-dir-item').forEach(item => {
          const itemCat = item.getAttribute('data-cat');
          if (cat === 'all' || itemCat === cat || itemCat === 'all') {
            item.style.display = 'flex';
          } else {
            item.style.display = 'none';
          }
        });
      });
    });

    // Привязка пикеров "Даты" и "Ночи"
    bindCustomPicker('tsDatesTrigger', 'tsDatesPicker', 'tsDates', (val) => {
      state.dateRange = val;
    });

    bindCustomPicker('tsNightsTrigger', 'tsNightsPicker', 'tsNights', (val) => {
      state.nights = val;
      doSearch();
    });

    // Закрытие при клике мимо или Esc
    document.addEventListener('click', function() {
      closeAllPickers();
    });

    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeAllPickers();
      }
    });

    // 4. Пикер туристов со счетчиками (+/-) и кнопкой "Готово"
    const touristsBtn = document.getElementById('tsTouristsToggle');
    const touristsDropdown = document.getElementById('tsTouristsDropdown');
    const touristsSummary = document.getElementById('tsTouristsSummary');
    const touristsSubText = document.getElementById('tsTouristsSubText');
    const touristsDone = document.getElementById('tsTouristsDone');

    if (touristsBtn && touristsDropdown) {
      touristsBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        const isOpen = touristsDropdown.classList.contains('show');
        closeAllPickers();
        if (!isOpen) {
          touristsDropdown.classList.add('show');
          touristsBtn.classList.add('open');
        }
      });

      touristsDropdown.addEventListener('click', function(e) {
        e.stopPropagation();
      });

      if (touristsDone) {
        touristsDone.addEventListener('click', function(e) {
          e.stopPropagation();
          closeAllPickers();
        });
      }

      const adultPlus = document.getElementById('tsAdultPlus');
      const adultMinus = document.getElementById('tsAdultMinus');
      const childPlus = document.getElementById('tsChildPlus');
      const childMinus = document.getElementById('tsChildMinus');
      const adultVal = document.getElementById('tsAdultVal');
      const childVal = document.getElementById('tsChildVal');

      function updateTouristsUI() {
        if (adultVal) adultVal.textContent = state.adults;
        if (childVal) childVal.textContent = state.children;
        if (touristsSummary) {
          let text = state.adults + (state.adults === 1 ? ' взрослый' : (state.adults < 5 ? ' взрослых' : ' взрослых'));
          if (state.children > 0) {
            text += ', ' + state.children + (state.children === 1 ? ' реб.' : ' дет.');
          }
          touristsSummary.textContent = text;
        }
        if (touristsSubText) {
          touristsSubText.textContent = state.children > 0 ? (state.children + ' дет. до 11 лет') : 'Без детей';
        }
      }

      if (adultPlus) {
        adultPlus.addEventListener('click', (e) => {
          e.stopPropagation();
          if (state.adults < 9) state.adults++;
          updateTouristsUI();
        });
      }

      if (adultMinus) {
        adultMinus.addEventListener('click', (e) => {
          e.stopPropagation();
          if (state.adults > 1) state.adults--;
          updateTouristsUI();
        });
      }

      if (childPlus) {
        childPlus.addEventListener('click', (e) => {
          e.stopPropagation();
          if (state.children < 5) state.children++;
          updateTouristsUI();
        });
      }

      if (childMinus) {
        childMinus.addEventListener('click', (e) => {
          e.stopPropagation();
          if (state.children > 0) state.children--;
          updateTouristsUI();
        });
      }

      updateTouristsUI();
    }

    // Initial render
    doSearch();
  }

  function doSearch() {
    const results = filterMockTours({
      direction: state.direction,
      from: state.from,
      hotelStars: state.hotelStars,
      instantOnly: state.instantOnly,
      tab: state.activeTab
    });
    renderResults(results);
  }

  function scrollToResults() {
    const resSec = document.getElementById('searchResultsSection');
    if (resSec) {
      resSec.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function setAudienceMode(mode) {
    state.audienceMode = mode;
    try {
      localStorage.setItem('tourput_audience_mode', mode);
    } catch(e){}

    // Update audience switchers across whole document
    document.querySelectorAll('.audience-tab, [data-audience]').forEach(btn => {
      const bAud = btn.getAttribute('data-audience');
      btn.classList.toggle('active', bAud === mode);
      btn.setAttribute('aria-selected', bAud === mode ? 'true' : 'false');
    });

    // Update body / container attribute for CSS hooks
    document.body.setAttribute('data-audience-mode', mode);

    const b2bNotif = document.getElementById('b2bBannerNotification');
    if (b2bNotif) {
      b2bNotif.style.display = (mode === 'agencies') ? 'flex' : 'none';
    }

    // Re-render search results to display/hide agency commissions
    doSearch();
  }

  // Auto init on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTourSearch);
  } else {
    initTourSearch();
  }

  window.initTourSearch = initTourSearch;
  window.setAudienceMode = setAudienceMode;

})(window, document);
