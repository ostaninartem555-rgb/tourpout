// Баннер согласия с политикой: показ один раз до принятия/отклонения.
// В iframe (виджет) не показывается — там согласие чекбоксом.
(function(){
  const KEY = "turput_consent_v1";
  try{
    if(localStorage.getItem(KEY)) return;
    if(window.self !== window.top) return;
  }catch(e){ return; }

  function accept(val){
    try{ localStorage.setItem(KEY, val); }catch(e){}
    const b = document.getElementById("consentBanner");
    if(b){ b.classList.remove("show"); setTimeout(function(){ b.remove(); }, 400); }
  }

  function build(){
    const d = document.createElement("div");
    d.id = "consentBanner";
    d.className = "consent";
    d.setAttribute("role", "dialog");
    d.setAttribute("aria-label", "Согласие на обработку данных");
    d.innerHTML =
      '<span>Мы обрабатываем ваши данные (имя, телефон) для подбора тура. Подробности — в <a href="privacy.html">политике конфиденциальности</a>.</span>' +
      '<span class="consent-btns"><button class="btn" id="consentOk">Принимаю</button>' +
      '<button class="btn ghost" id="consentNo">Отклонить</button></span>';
    document.body.appendChild(d);
    document.getElementById("consentOk").addEventListener("click", function(){ accept("yes"); });
    document.getElementById("consentNo").addEventListener("click", function(){ accept("no"); });
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ d.classList.add("show"); }); });
  }

  if(document.body) setTimeout(build, 800);
  else document.addEventListener("DOMContentLoaded", function(){ setTimeout(build, 800); });
})();
