// ТУР ПУТЬ — 3D фон: реалистичная анимация падающего снега + глубина + интерактивный параллакс курсора.
// Поддерживает как главный экран поиска (#searchSpace3d), так и блок с карточками (#space3d).
(function(){
  'use strict';
  const fineHover = window.matchMedia && window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  let mx = 0, my = 0;

  // Глобальный параллакс от движения мыши
  window.addEventListener('mousemove', e => {
    mx = (e.clientX / window.innerWidth - 0.5) * 2;
    my = (e.clientY / window.innerHeight - 0.5) * 2;
  }, { passive: true });

  // Параллакс от касания на мобильных устройствах
  window.addEventListener('touchmove', e => {
    if(e.touches && e.touches[0]){
      mx = (e.touches[0].clientX / window.innerWidth - 0.5) * 1.5;
      my = (e.touches[0].clientY / window.innerHeight - 0.5) * 1.5;
    }
  }, { passive: true });

  // Функция создания и запуска 3D-снежного холста
  function initSnowCanvas(cv, hasHills, flakeCount){
    if(!cv) return;
    const ctx = cv.getContext('2d');
    let W = 0, H = 0;
    const N = flakeCount || 140;
    const flakes = [];

    function resize(){
      if(!cv || !cv.parentElement) return;
      const r = cv.parentElement.getBoundingClientRect();
      W = cv.width = Math.max(1, Math.floor(r.width));
      H = cv.height = Math.max(1, Math.floor(r.height));
    }

    window.addEventListener('resize', resize);
    if(window.ResizeObserver && cv.parentElement){
      new ResizeObserver(() => resize()).observe(cv.parentElement);
    }
    resize();
    setTimeout(resize, 200);

    // Инициализация хлопьев снега
    for(let i = 0; i < N; i++){
      flakes.push({
        x: Math.random(),
        y: Math.random(),
        z: 0.25 + Math.random() * 0.75, // глубина слоя (0.25..1)
        r: 1.4 + Math.random() * 2.8,    // видимый размер хлопьев (1.4..4.2px)
        speed: 0.0006 + Math.random() * 0.0016, // скорость падения
        swayPhase: Math.random() * Math.PI * 2,  // фаза покачивания
        swaySpeed: 0.0015 + Math.random() * 0.002, // частота покачивания
        swayAmp: 8 + Math.random() * 16           // амплитуда колыхания
      });
    }

    // Силуэт гор внизу (для нижнего 3D блока)
    function hills(t){
      ctx.beginPath();
      ctx.moveTo(0, H);
      for(let x = 0; x <= W; x += 8){
        const y = H - 90 + Math.sin(x * 0.008 + t * 0.6) * 22 + Math.sin(x * 0.02 - t * 0.4) * 10;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(W, H);
      ctx.closePath();
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const g = ctx.createLinearGradient(0, H - 140, 0, H);
      if(isDark){
        g.addColorStop(0, 'rgba(42, 127, 255, 0.28)');
        g.addColorStop(1, 'rgba(11, 16, 32, 0)');
      } else {
        g.addColorStop(0, 'rgba(59, 130, 246, 0.16)');
        g.addColorStop(1, 'rgba(255, 255, 255, 0)');
      }
      ctx.fillStyle = g;
      ctx.fill();
    }

    // Главный цикл анимации снега
    function tick(t){
      ctx.clearRect(0, 0, W, H);
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

      // Мягкое фоновое радиальное сияние от курсора
      const gx = W * 0.5 + mx * 25;
      const gy = H * 0.28 + my * 18;
      const glow = ctx.createRadialGradient(gx, gy, 0, gx, gy, Math.max(280, Math.min(W, H) * 0.6));
      if(isDark){
        glow.addColorStop(0, 'rgba(124, 92, 255, 0.22)');
        glow.addColorStop(0.5, 'rgba(42, 127, 255, 0.10)');
        glow.addColorStop(1, 'rgba(124, 92, 255, 0)');
      } else {
        glow.addColorStop(0, 'rgba(42, 127, 255, 0.10)');
        glow.addColorStop(0.6, 'rgba(124, 92, 255, 0.04)');
        glow.addColorStop(1, 'rgba(255, 255, 255, 0)');
      }
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, W, H);

      // Фоновый легкий бриз
      const idleBreeze = Math.sin(t * 0.0006) * 10;

      // Отрисовка хлопьев снега
      for(let i = 0; i < flakes.length; i++){
        const s = flakes[i];
        s.y += s.speed;
        if(s.y > 1.02){
          s.y = -0.02;
          s.x = Math.random();
        }

        // Плавное покачивание снежинки на ветру
        const sway = Math.sin(t * s.swaySpeed + s.swayPhase) * s.swayAmp;
        const px = ((s.x * W + mx * 35 * s.z + sway + idleBreeze * s.z) % W + W) % W;
        const py = s.y * H + my * 20 * s.z;
        const alpha = 0.35 + s.z * 0.60;
        const radius = s.r * (0.6 + s.z * 0.5);

        ctx.beginPath();
        ctx.arc(px, py, radius, 0, Math.PI * 2);
        if(isDark){
          ctx.fillStyle = 'rgba(235, 245, 255, ' + alpha.toFixed(2) + ')';
          ctx.shadowColor = 'rgba(180, 220, 255, 0.6)';
          ctx.shadowBlur = 4 * s.z;
        } else {
          ctx.fillStyle = 'rgba(70, 130, 235, ' + (alpha * 0.40).toFixed(2) + ')';
          ctx.shadowColor = 'rgba(59, 130, 246, 0.3)';
          ctx.shadowBlur = 3 * s.z;
        }
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      if(hasHills) hills(t * 0.001);
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  // 1. Инициализация 3D-анимации снега на первой странице (поисковый раздел)
  initSnowCanvas(document.getElementById('searchSpace3d'), false, 130);

  // 2. Инициализация 3D-анимации снега на втором экране (#space3d с горами и карточками)
  initSnowCanvas(document.getElementById('space3d'), true, 150);

  // 3. Плавный 3D-tilt для интерактивных карточек
  if(!fineHover) return;
  document.querySelectorAll('[data-tilt]').forEach(el => {
    let tx = 0, ty = 0, cx = 0, cy = 0, raf = 0;
    const max = parseFloat(el.getAttribute('data-tilt-max') || '8');
    function render(){
      cx += (tx - cx) * 0.14;
      cy += (ty - cy) * 0.14;
      el.style.setProperty('--ry', cx.toFixed(2) + 'deg');
      el.style.setProperty('--rx', cy.toFixed(2) + 'deg');
      if(Math.abs(tx - cx) > 0.02 || Math.abs(ty - cy) > 0.02){
        raf = requestAnimationFrame(render);
      } else {
        cx = tx; cy = ty;
        el.style.setProperty('--ry', cx.toFixed(2) + 'deg');
        el.style.setProperty('--rx', cy.toFixed(2) + 'deg');
        raf = 0;
      }
    }
    function kick(){ if(!raf) raf = requestAnimationFrame(render); }
    el.addEventListener('mouseenter', () => { tx = 0; ty = 0; kick(); });
    el.addEventListener('mousemove', e => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      tx = Math.max(-max, Math.min(max, px * max));
      ty = Math.max(-max, Math.min(max, -py * max));
      kick();
    });
    el.addEventListener('mouseleave', () => { tx = 0; ty = 0; kick(); });
  });
})();
