/**
 * ТУР ПУТЬ — Комплексная система безопасности и детектор ошибок
 *
 * Архитектурные функции:
 *  1. Глобальный перехват JS-ошибок (window.onerror)
 *  2. Перехват неразрешенных промисов (window.onunhandledrejection)
 *  3. Мониторинг сбоев ресурсов (Resource Load Errors)
 *  4. Санитайзер ввода от XSS-атак (XSS Defense)
 *  5. Защита от спама и ботов (Honeypot + Human Delay Timer + Rate Limiter)
 *  6. Безопасное хранилище (Storage Guard)
 *  7. TELEGRAM ALERT DISPATCHER — моментальная отправка алертов о падениях сайта в Telegram владельца.
 *  8. TOURCLICK CRM CONNECTOR — привязка Webhook Tourclick для заявок туристов.
 *  9. Административная консоль диагностики (Admin Security Console)
 *
 * ЗАЩИТА И ДОСТУП:
 *  - Модуль работает в автономном фоновом режиме.
 *  - Доступ администратора защищён криптографической аутентификацией SHA-256.
 */

(function(){
  'use strict';

  const STORAGE_KEY = 'turput_error_logs_v2';
  const ADMIN_KEY = 'turput_admin_mode';
  const TG_TOKEN_KEY = 'turput_tg_bot_token';
  const TG_CHAT_KEY = 'turput_tg_chat_id';
  const TG_ENABLED_KEY = 'turput_tg_enabled';
  const TC_URL_KEY = 'turput_tourclick_url';
  const DEFAULT_TG_TOKEN = '8904060451:AAG4-8UbMlrCdyvx48ByMy6AVudsOxPuMck';
  const DEFAULT_BOT_USERNAME = 'detectorerrorbot';
  const DEFAULT_TG_CHAT_ID = '5646411325';
  const MAX_LOGS = 50;

  // Безопасное хранилище
  const MemoryStore = {
    data: {},
    get: function(k){
      try { return localStorage.getItem(k); }
      catch(e){ return this.data[k] || null; }
    },
    set: function(k, v){
      try { localStorage.setItem(k, v); }
      catch(e){ this.data[k] = String(v); }
    }
  };

  const ADMIN_SALT = 'turput_salt_2026_';
  const ADMIN_HASH = '164b7656c5915c589402b88202b43f24268545495991f8e9f1138915e4b77aa5';
  const HK_HASH = 'fe9c67b0f4a0d8d6d1908a38aed03f0ee561ad79f96db2023bb4a36d5039db49';

  function sha256Fallback(ascii){
    function rightRotate(v, a){ return (v >>> a) | (v << (32 - a)); }
    var mathPow = Math.pow, maxWord = mathPow(2, 32), result = '', words = [];
    var asciiBitLength = ascii.length * 8, hash = [], k = [], primeCounter = 0, isComposite = {};
    for(var c = 2; primeCounter < 64; c++){
      if(!isComposite[c]){
        for(var i = 0; i < 313; i += c) isComposite[i] = c;
        hash[primeCounter] = (mathPow(c, 0.5) * maxWord) | 0;
        k[primeCounter++] = (mathPow(c, 1/3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while((ascii.length % 64) !== 56) ascii += '\x00';
    for(var i = 0; i < ascii.length; i++){
      var j = ascii.charCodeAt(i);
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = ((asciiBitLength / maxWord) | 0);
    words[words.length] = (asciiBitLength) | 0;
    for(var j = 0; j < words.length;){
      var w = words.slice(j, j += 16), oldHash = hash;
      hash = hash.slice(0, 8);
      for(var i = 0; i < 64; i++){
        var w15 = w[i - 15], w2 = w[i - 2];
        var a = hash[0], e = hash[4];
        var temp1 = hash[7]
          + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25))
          + ((e & hash[5]) ^ ((~e) & hash[6]))
          + k[i]
          + (w[i] = (i < 16) ? w[i] : (
              w[i - 16]
              + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3))
              + w[i - 7]
              + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
            ) | 0);
        var temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22))
          + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for(var i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for(var i = 0; i < 8; i++){
      for(var i2 = 3; i2 >= 0; i2--){
        var b = (hash[i] >> (i2 * 8)) & 255;
        result += ((b < 16) ? '0' : '') + b.toString(16);
      }
    }
    return result;
  }

  async function verifyPassword(pwd){
    try {
      if(window.crypto && window.crypto.subtle){
        const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(ADMIN_SALT + String(pwd || '').trim()));
        const hash = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
        return hash === ADMIN_HASH;
      }
    } catch(e){}
    return sha256Fallback(ADMIN_SALT + String(pwd || '').trim()) === ADMIN_HASH;
  }

  let authModalEl = null;

  function showPasswordModal(onSuccess){
    if(authModalEl){
      authModalEl.style.display = 'flex';
      const inp = authModalEl.querySelector('#turputAdminPassInput');
      if(inp){ inp.value = ''; inp.focus(); }
      const err = authModalEl.querySelector('#turputAdminPassError');
      if(err) err.style.display = 'none';
      return;
    }

    authModalEl = document.createElement('div');
    authModalEl.id = 'turputAuthModal';
    authModalEl.style.cssText = [
      'position: fixed',
      'inset: 0',
      'z-index: 1000000',
      'background: rgba(4, 7, 16, 0.85)',
      'backdrop-filter: blur(10px)',
      'display: flex',
      'align-items: center',
      'justify-content: center',
      'padding: 20px',
      'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    ].join(';');

    authModalEl.innerHTML = `
      <div style="background:#0e162d;border:1px solid rgba(42,127,255,0.45);border-radius:20px;max-width:390px;width:100%;box-shadow:0 24px 70px rgba(0,0,0,0.85);color:#eef2ff;padding:24px;position:relative;animation:turputFadeIn .2s ease">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
          <div style="width:42px;height:42px;border-radius:12px;background:rgba(42,127,255,0.15);border:1px solid #2a7fff;display:flex;align-items:center;justify-content:center;font-size:22px">🔒</div>
          <div>
            <h3 style="margin:0;font-size:16px;font-weight:700;color:#fff">Вход администратора</h3>
            <p style="margin:2px 0 0;font-size:11px;color:#9aa8c7">Панель управления ТУР ПУТЬ</p>
          </div>
        </div>

        <p style="font-size:12px;color:#cbd5e1;margin:0 0 14px;line-height:1.4">
          Для доступа к аналитике, статистике и настройкам введите секретный пароль:
        </p>

        <form id="turputAdminAuthForm" style="display:flex;flex-direction:column;gap:12px" onsubmit="return false;">
          <div>
            <input id="turputAdminPassInput" type="password" placeholder="Введите пароль..." autocomplete="current-password" autofocus style="width:100%;box-sizing:border-box;background:#090e1f;border:1px solid rgba(255,255,255,0.22);border-radius:10px;padding:10px 14px;color:#fff;font-size:14px;outline:none;letter-spacing:1px">
            <div id="turputAdminPassError" style="display:none;color:#f43f5e;font-size:11px;font-weight:600;margin-top:6px;padding-left:2px">
              ❌ Неверный пароль. Доступ заблокирован.
            </div>
          </div>

          <div style="display:flex;gap:8px;margin-top:4px">
            <button id="btnSubmitAdminAuth" type="submit" style="flex:1;background:linear-gradient(135deg, #2a7fff, #1d60c4);color:#fff;border:0;border-radius:10px;padding:10px;font-size:13px;font-weight:700;cursor:pointer">Войти</button>
            <button id="btnCancelAdminAuth" type="button" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);color:#9aa8c7;border-radius:10px;padding:10px 14px;font-size:13px;font-weight:600;cursor:pointer">Отмена</button>
          </div>
        </form>
      </div>
    `;

    document.body.appendChild(authModalEl);

    const input = authModalEl.querySelector('#turputAdminPassInput');
    const errBox = authModalEl.querySelector('#turputAdminPassError');
    const form = authModalEl.querySelector('#turputAdminAuthForm');
    const cancelBtn = authModalEl.querySelector('#btnCancelAdminAuth');

    function closeAuth(){
      if(authModalEl) authModalEl.style.display = 'none';
      if(errBox) errBox.style.display = 'none';
    }

    cancelBtn.addEventListener('click', closeAuth);
    authModalEl.addEventListener('click', function(e){
      if(e.target === authModalEl) closeAuth();
    });

    window.addEventListener('keydown', function(e){
      if(e.key === 'Escape' && authModalEl && authModalEl.style.display !== 'none'){
        closeAuth();
      }
    });

    form.addEventListener('submit', async function(e){
      e.preventDefault();
      const val = input.value;
      const ok = await verifyPassword(val);
      if(ok){
        closeAuth();
        MemoryStore.set(ADMIN_KEY, 'true');
        showToast('🛡️ Пароль верный! Панель администратора активирована', true);
        updateBadgeVisibility();
        if(typeof onSuccess === 'function') onSuccess();
      } else {
        errBox.style.display = 'block';
        input.style.borderColor = '#f43f5e';
        input.value = '';
        input.focus();
        if(input.animate){
          input.animate([
            { transform: 'translateX(0)' },
            { transform: 'translateX(-6px)' },
            { transform: 'translateX(6px)' },
            { transform: 'translateX(-4px)' },
            { transform: 'translateX(4px)' },
            { transform: 'translateX(0)' }
          ], { duration: 250 });
        }
      }
    });

    setTimeout(() => { if(input) input.focus(); }, 60);
  }

  // Проверка прав администратора
  // По умолчанию плашка 100% СКРЫТА от всех обычных посетителей сайта!
  function isAdmin(){
    const stored = MemoryStore.get(ADMIN_KEY);
    return stored === 'true';
  }

  function toggleAdminMode(forceState){
    const current = isAdmin();
    const nextState = (typeof forceState === 'boolean') ? forceState : !current;
    MemoryStore.set(ADMIN_KEY, nextState ? 'true' : 'false');

    if(!nextState){
      // 1. Очищаем ?admin и ?debug из адресной строки, чтобы перезагрузка не возвращала плашку
      try {
        const url = new URL(window.location.href);
        if(url.searchParams.has('admin') || url.searchParams.has('debug')){
          url.searchParams.delete('admin');
          url.searchParams.delete('debug');
          const cleanSearch = url.searchParams.toString();
          const newUrl = url.pathname + (cleanSearch ? '?' + cleanSearch : '') + url.hash;
          window.history.replaceState({}, document.title, newUrl);
        }
      } catch(e){}

      // 2. Немедленно скрываем модальное окно
      if(modalEl){
        modalEl.style.display = 'none';
      }

      // 3. Немедленно скрываем плашку
      if(badgeEl){
        badgeEl.style.setProperty('display', 'none', 'important');
      }

      showToast('🔒 Режим администратора: ВЫКЛЮЧЕН. Плашка скрыта от всех!', false);
    } else {
      if(badgeEl){
        badgeEl.style.setProperty('display', 'flex', 'important');
      }
      showToast('🛡️ Режим администратора: ВКЛЮЧЕН (плашка видна)', true);
    }

    updateBadgeVisibility();
  }

  function showToast(msg, isSuccess){
    let t = document.getElementById('turputToast');
    if(!t){
      t = document.createElement('div');
      t.id = 'turputToast';
      t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#151f3d;color:#fff;border:1px solid #2a7fff;padding:10px 20px;border-radius:12px;font:13px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;z-index:999999;box-shadow:0 8px 30px rgba(0,0,0,0.8);transition:opacity .3s;pointer-events:none';
      document.body.appendChild(t);
    }
    t.style.borderColor = isSuccess ? '#22c55e' : (isSuccess === false ? '#ef4444' : '#2a7fff');
    t.textContent = msg;
    t.style.opacity = '1';
    setTimeout(() => { if(t) t.style.opacity = '0'; }, 3500);
  }

  function getLogs(){
    try {
      const raw = MemoryStore.get(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) {
      return [];
    }
  }

  function saveLogs(logs){
    try {
      MemoryStore.set(STORAGE_KEY, JSON.stringify(logs.slice(-MAX_LOGS)));
    } catch(e){}
  }

  // --- TELEGRAM ALERTING DISPATCHER ---
  let lastTgAlertTime = 0;
  let lastTgAlertMsg = '';

  async function sendTelegramAlert(entry, isTest){
    const token = (MemoryStore.get(TG_TOKEN_KEY) || DEFAULT_TG_TOKEN || (window.TURPUT_CONFIG && window.TURPUT_CONFIG.telegram && window.TURPUT_CONFIG.telegram.botToken) || '').trim();
    const chatId = (MemoryStore.get(TG_CHAT_KEY) || DEFAULT_TG_CHAT_ID || (window.TURPUT_CONFIG && window.TURPUT_CONFIG.telegram && window.TURPUT_CONFIG.telegram.chatId) || '').trim();
    const enabled = MemoryStore.get(TG_ENABLED_KEY) !== 'false';

    if(!token || !chatId){
      if(isTest){
        showToast('❌ Укажите Telegram Bot Token и Chat ID в панели ниже', false);
      }
      return { ok: false, reason: 'Telegram не настроен' };
    }

    if(!isTest && !enabled){
      return { ok: false, reason: 'Уведомления выключены' };
    }

    // Защита от спама (rate limiting: не чаще 1 сообщения раз в 15 секунд при одинаковых ошибках)
    const now = Date.now();
    if(!isTest && (now - lastTgAlertTime < 15000) && lastTgAlertMsg === (entry && entry.message)){
      return { ok: false, reason: 'Throttled' };
    }
    lastTgAlertTime = now;
    if(entry) lastTgAlertMsg = entry.message;

    let text = '';
    if(isTest){
      text = '🔔 <b>ТУР ПУТЬ — Проверка связи с Telegram</b>\n\n' +
             '✅ <b>Интеграция настроена успешно!</b>\n' +
             'Если на сайте возникнет сбой, падение или ошибка отправки заявки — вы мгновенно получите сообщение сюда.\n\n' +
             '⏰ <i>' + new Date().toLocaleTimeString('ru-RU') + '</i>';
    } else {
      text = '🚨 <b>ВНИМАНИЕ: СБОЙ НА САЙТЕ ТУР ПУТЬ!</b>\n\n' +
             '⚠️ <b>Тип:</b> <code>' + (entry.type || 'RuntimeError') + '</code>\n' +
             '📄 <b>Страница:</b> ' + (window.location.pathname || '/') + '\n' +
             '💬 <b>Текст сбоя:</b>\n<pre>' + String(entry.message || 'Unknown').slice(0, 350) + '</pre>\n' +
             '📍 <b>Источник:</b> ' + String(entry.source || 'inline').slice(0, 100) + (entry.line ? ':' + entry.line : '') + '\n' +
             '⏰ <b>Время:</b> ' + (entry.time || new Date().toLocaleTimeString('ru-RU')) + '\n' +
             '🌐 <b>URL:</b> ' + window.location.href;
    }

    try {
      const resp = await fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: text,
          parse_mode: 'HTML',
          disable_web_page_preview: true
        })
      });
      const data = await resp.json();
      if(isTest){
        if(data.ok){
          showToast('✓ Тестовое уведомление успешно доставлено в Telegram!', true);
        } else {
          showToast('❌ Ошибка Telegram: ' + (data.description || 'Неверный токен или chat_id'), false);
        }
      }
      return data;
    } catch(err){
      if(isTest){
        showToast('❌ Ошибка соединения с Telegram API: ' + (err.message || err), false);
      }
      return { ok: false, error: err };
    }
  }

  async function autoDetectTelegramChatId(customToken){
    const token = (customToken || MemoryStore.get(TG_TOKEN_KEY) || DEFAULT_TG_TOKEN).trim();
    if(!token) return { ok: false, error: 'Токен не указан' };

    try {
      const resp = await fetch('https://api.telegram.org/bot' + token + '/getUpdates');
      const data = await resp.json();
      if(!data.ok){
        return { ok: false, error: data.description || 'Ошибка Telegram API' };
      }
      if(!data.result || data.result.length === 0){
        return { ok: false, empty: true, error: 'В боте пока нет сообщений. Откройте @' + DEFAULT_BOT_USERNAME + ' в Telegram и нажмите Запустить (Start).' };
      }
      for(let i = data.result.length - 1; i >= 0; i--){
        const u = data.result[i];
        const chat = (u.message && u.message.chat) || (u.edited_message && u.edited_message.chat) || (u.callback_query && u.callback_query.message && u.callback_query.message.chat);
        if(chat && chat.id){
          const foundId = String(chat.id);
          MemoryStore.set(TG_CHAT_KEY, foundId);
          return { ok: true, chatId: foundId, from: chat.first_name || chat.username || 'Пользователь' };
        }
      }
      return { ok: false, error: 'Chat ID не найден в обновлениях.' };
    } catch(e){
      return { ok: false, error: e.message || String(e) };
    }
  }


  // --- МОДУЛЬ ЗАЩИТЫ (SECURITY MODULE) ---
  window.TurputSecurity = {
    sanitizeHTML: function(str){
      if(!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\//g, '&#x2F;');
    },
    validatePhone: function(phone){
      const digits = String(phone || '').replace(/\D/g, '');
      return digits.length >= 10 && digits.length <= 15;
    },
    checkRateLimit: function(actionKey, cooldownSec){
      const key = 'turput_rl_' + actionKey;
      const last = parseInt(MemoryStore.get(key) || '0', 10);
      const now = Date.now();
      if(now - last < cooldownSec * 1000){
        const left = Math.ceil((cooldownSec * 1000 - (now - last)) / 1000);
        return { allowed: false, secondsLeft: left };
      }
      MemoryStore.set(key, String(now));
      return { allowed: true, secondsLeft: 0 };
    },
    isHumanBehavior: function(startTimeMs, minMs){
      return (Date.now() - startTimeMs) >= (minMs || 2000);
    },
    toggleAdmin: toggleAdminMode,
    showPasswordModal: showPasswordModal,
    isAdmin: isAdmin,
    sendTelegramAlert: sendTelegramAlert
  };

  // --- ДЕТЕКТОР ОШИБОК (ERROR DETECTOR) ---
  function recordError(type, message, source, lineno, colno, stack){
    const entry = {
      id: 'err_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      type: type || 'RuntimeError',
      message: String(message || 'Неизвестная ошибка').slice(0, 500),
      source: String(source || window.location.pathname).slice(0, 200),
      line: lineno || 0,
      col: colno || 0,
      stack: String(stack || '').slice(0, 800),
      page: window.location.href,
      time: new Date().toLocaleTimeString('ru-RU') + ' (' + new Date().toISOString().slice(0, 10) + ')'
    };

    const logs = getLogs();
    logs.push(entry);
    saveLogs(logs);

    // Автоматическая отправка алерта о падении в Telegram!
    sendTelegramAlert(entry, false);

    try {
      if(window.Sentry && typeof window.Sentry.captureMessage === 'function'){
        window.Sentry.captureMessage(entry.message, {
          level: 'error',
          tags: { type: entry.type, source: entry.source },
          extra: entry
        });
      }
    } catch(e){}

    updateUI(logs.length);
    renderModalLogs();
    return entry;
  }

  // 1. Синхронные ошибки JS
  window.addEventListener('error', function(event){
    if(event.target && (event.target.tagName === 'IMG' || event.target.tagName === 'SCRIPT' || event.target.tagName === 'LINK')){
      const src = event.target.src || event.target.href || 'unknown';
      recordError('ResourceLoadError', 'Не удалось загрузить ресурс: ' + src, event.target.tagName, 0, 0);
      return;
    }
    recordError('JSError', event.message, event.filename, event.lineno, event.colno, event.error ? event.error.stack : '');
  }, true);

  // 2. Асинхронные ошибки промисов
  window.addEventListener('unhandledrejection', function(event){
    const reason = event.reason;
    const msg = reason && (reason.message || reason) || 'Необработанное отклонение Promise';
    const stack = reason && reason.stack ? reason.stack : '';
    recordError('PromiseRejection', msg, 'async/promise', 0, 0, stack);
  });

  window.reportError = function(msg, source, extra){
    return recordError('ManualReport', msg, source, 0, 0, JSON.stringify(extra || {}));
  };

  window.triggerTestError = function(){
    setTimeout(function(){
      throw new Error('ТЕСТОВАЯ ОШИБКА: Детектор ТУР ПУТЬ успешно перехватил исключение!');
    }, 50);
  };

  window.triggerTestPromiseRejection = function(){
    Promise.reject(new Error('ТЕСТОВЫЙ СБОЙ PROMISE: Асинхронный перехватчик сработал штатно!'));
  };

  // --- ИНТЕРФЕЙС ПЛАШКИ (ВИДЕН ТОЛЬКО АДМИНУ) ---
  let badgeEl = null;
  let modalEl = null;

  function updateBadgeVisibility(){
    if(badgeEl){
      if(isAdmin()){
        badgeEl.style.setProperty('display', 'flex', 'important');
      } else {
        badgeEl.style.setProperty('display', 'none', 'important');
        if(modalEl && modalEl.style.display !== 'none'){
          modalEl.style.display = 'none';
        }
      }
    }
    if(document.body){
      if(isAdmin()){
        document.body.classList.add('admin-authorized');
      } else {
        document.body.classList.remove('admin-authorized');
      }
    }
  }

  function createUI(){
    if(badgeEl) return;

    badgeEl = document.createElement('div');
    badgeEl.id = 'turputSecurityBadge';
    badgeEl.style.cssText = [
      'position: fixed',
      'left: 14px',
      'bottom: 14px',
      'z-index: 99999',
      'display: none',
      'align-items: center',
      'gap: 8px',
      'padding: 8px 14px',
      'border-radius: 100px',
      'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      'font-size: 13px',
      'font-weight: 600',
      'cursor: pointer',
      'box-shadow: 0 8px 24px rgba(0,0,0,0.5)',
      'transition: all 0.25s ease',
      'backdrop-filter: blur(10px)',
      'user-select: none'
    ].join(';');

    badgeEl.title = 'Центр безопасности ТУР ПУТЬ (Виден только администратору)';
    badgeEl.addEventListener('click', toggleModal);
    badgeEl.addEventListener('mouseenter', function(){ badgeEl.style.transform = 'translateY(-2px) scale(1.02)'; });
    badgeEl.addEventListener('mouseleave', function(){ badgeEl.style.transform = 'none'; });

    modalEl = document.createElement('div');
    modalEl.id = 'turputSecurityModal';
    modalEl.style.cssText = [
      'position: fixed',
      'inset: 0',
      'z-index: 100000',
      'background: rgba(4, 7, 16, 0.75)',
      'backdrop-filter: blur(8px)',
      'display: none',
      'align-items: center',
      'justify-content: center',
      'padding: 20px',
      'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    ].join(';');

    const curTgToken = MemoryStore.get(TG_TOKEN_KEY) || DEFAULT_TG_TOKEN;
    const curTgChat = MemoryStore.get(TG_CHAT_KEY) || DEFAULT_TG_CHAT_ID;
    const curTcUrl = MemoryStore.get(TC_URL_KEY) || '';
    const curLeadEmail = MemoryStore.get('tourput_lead_email') || '';
    const curB2bEmail = MemoryStore.get('tourput_b2b_email') || 'agents@tourput.ru';
    const curSbUrl = MemoryStore.get('turput_supabase_url') || 'https://jbfzzommtuchhoaqsevy.supabase.co';
    const curSbKey = MemoryStore.get('turput_supabase_key') || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpiZnp6b21tdHVjaGhvYXFzZXZ5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MjA3NDg3NSwiZXhwIjoyMTA3NjUwODc1fQ.3frZImvFtiplKtyTkOYbrd1-2eJI6F5SZwNiEtcO0hw';

    modalEl.innerHTML = `
      <div style="background:#0e162d;border:1px solid rgba(255,255,255,0.18);border-radius:20px;max-width:740px;width:100%;max-height:88vh;display:flex;flex-direction:column;box-shadow:0 24px 70px rgba(0,0,0,0.8);color:#eef2ff;overflow:hidden">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 24px;border-bottom:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.02)">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:22px">🛡️</span>
            <div>
              <h3 style="margin:0;font-size:17px;font-weight:700">Панель управления: Безопасность, Трафик & Интеграции</h3>
              <p style="margin:2px 0 0;font-size:12px;color:#9aa8c7">Обычные посетители сайта эту панель не видят (доступна только владельцу)</p>
            </div>
          </div>
          <button id="closeSecurityModal" style="background:none;border:0;color:#9aa8c7;font-size:24px;cursor:pointer;line-height:1;padding:4px 8px">&times;</button>
        </div>

        <div style="padding:20px 24px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:18px">

          <!-- Блок статусов защиты -->
          <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(120px, 1fr));gap:10px">
            <div style="background:rgba(42,127,255,0.08);border:1px solid rgba(42,127,255,0.25);border-radius:12px;padding:10px">
              <div style="font-size:11px;color:#9aa8c7;text-transform:uppercase;font-weight:700">XSS Защита</div>
              <div style="font-size:13px;font-weight:600;color:#52e396;margin-top:3px">● Активна</div>
            </div>
            <div style="background:rgba(42,127,255,0.08);border:1px solid rgba(42,127,255,0.25);border-radius:12px;padding:10px">
              <div style="font-size:11px;color:#9aa8c7;text-transform:uppercase;font-weight:700">Антибот & Спам</div>
              <div style="font-size:13px;font-weight:600;color:#52e396;margin-top:3px">● Honeypot 2.5s</div>
            </div>
            <div style="background:rgba(42,127,255,0.08);border:1px solid rgba(42,127,255,0.25);border-radius:12px;padding:10px">
              <div style="font-size:11px;color:#9aa8c7;text-transform:uppercase;font-weight:700">Email туристов</div>
              <div id="emailHeaderStatus" style="font-size:13px;font-weight:600;color:${curLeadEmail ? '#52e396' : '#facc15'};margin-top:3px">● ${curLeadEmail ? 'Подключен' : 'Ждет почту'}</div>
            </div>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:12px;padding:10px">
              <div style="font-size:11px;color:#9aa8c7;text-transform:uppercase;font-weight:700">Email B2B агентств</div>
              <div id="b2bHeaderStatus" style="font-size:13px;font-weight:600;color:#52e396;margin-top:3px">● ${curB2bEmail ? 'Подключен' : 'Ждет почту'}</div>
            </div>
            <div style="background:rgba(42,127,255,0.08);border:1px solid rgba(42,127,255,0.25);border-radius:12px;padding:10px">
              <div style="font-size:11px;color:#9aa8c7;text-transform:uppercase;font-weight:700">Telegram Алерты</div>
              <div id="tgHeaderStatus" style="font-size:13px;font-weight:600;color:${(curTgToken && curTgChat) ? '#52e396' : '#facc15'};margin-top:3px">● ${(curTgToken && curTgChat) ? 'Подключен' : 'Ожидает бота'}</div>
            </div>
          </div>

          <!-- СЕКЦИЯ 0: ГРАФИК ПОСЕЩАЕМОСТИ И АНАЛИТИКА -->
          <div style="background:rgba(56,189,248,0.04);border:1px solid rgba(56,189,248,0.25);border-radius:14px;padding:14px;display:flex;flex-direction:column;gap:12px">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
              <div style="font-weight:700;font-size:14px;display:flex;align-items:center;gap:6px">
                <span>📈</span> Статистика посещаемости & Конверсии
              </div>
              <div style="display:flex;align-items:center;gap:10px;font-size:11px">
                <span style="display:inline-flex;align-items:center;gap:4px;color:#38bdf8"><span style="width:8px;height:8px;border-radius:50%;background:#38bdf8"></span> Просмотры</span>
                <span style="display:inline-flex;align-items:center;gap:4px;color:#22c55e"><span style="width:8px;height:8px;border-radius:50%;background:#22c55e"></span> Уникальные</span>
                <span style="display:inline-flex;align-items:center;gap:4px;color:#f59e0b"><span style="width:8px;height:8px;border-radius:50%;background:#f59e0b"></span> Заявки</span>
                <span id="sbBadge" style="padding:2px 8px;border-radius:6px;background:${curSbUrl ? 'rgba(34,197,94,0.15)' : 'rgba(56,189,248,0.15)'};color:${curSbUrl ? '#4ade80' : '#38bdf8'};font-weight:600">
                  ${curSbUrl ? '☁️ Supabase Cloud' : '🟢 Offline-First'}
                </span>
                <button id="btnRefreshAnalytics" type="button" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.18);color:#eef2ff;border-radius:6px;padding:2px 8px;font-size:11px;font-weight:600;cursor:pointer" title="Синхронизировать данные с Supabase">🔄 Обновить</button>
              </div>
            </div>

            <!-- KPI карточки -->
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:8px">
              <div style="background:rgba(9,14,31,0.7);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:8px 10px;text-align:center">
                <div style="font-size:10px;color:#9aa8c7;text-transform:uppercase">Просмотры (7д)</div>
                <div id="statViews" style="font-size:17px;font-weight:800;color:#38bdf8;margin-top:2px">—</div>
              </div>
              <div style="background:rgba(9,14,31,0.7);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:8px 10px;text-align:center">
                <div style="font-size:10px;color:#9aa8c7;text-transform:uppercase">Уникальные</div>
                <div id="statUniques" style="font-size:17px;font-weight:800;color:#22c55e;margin-top:2px">—</div>
              </div>
              <div style="background:rgba(9,14,31,0.7);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:8px 10px;text-align:center">
                <div style="font-size:10px;color:#9aa8c7;text-transform:uppercase">Заявки</div>
                <div id="statLeads" style="font-size:17px;font-weight:800;color:#f59e0b;margin-top:2px">—</div>
              </div>
              <div style="background:rgba(9,14,31,0.7);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:8px 10px;text-align:center">
                <div style="font-size:10px;color:#9aa8c7;text-transform:uppercase">Конверсия</div>
                <div id="statConversion" style="font-size:17px;font-weight:800;color:#eef2ff;margin-top:2px">—</div>
              </div>
            </div>

            <!-- Canvas интерактивный график -->
            <div style="position:relative;background:#090e1f;border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:10px 8px 4px;overflow:hidden">
              <canvas id="trafficChartCanvas" style="width:100%;height:190px;display:block;cursor:crosshair"></canvas>
              <div id="chartTooltip" style="position:absolute;display:none;pointer-events:none;background:#151f3d;border:1px solid #38bdf8;border-radius:8px;padding:6px 10px;font-size:11px;color:#fff;box-shadow:0 8px 24px rgba(0,0,0,0.8);white-space:nowrap;z-index:10;transform:translate(-50%, -120%)"></div>
            </div>

            <!-- Популярность направлений -->
            <div style="background:rgba(9,14,31,0.5);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:10px">
              <div style="font-size:11px;font-weight:700;color:#9aa8c7;margin-bottom:8px;text-transform:uppercase">Интерес к направлениям (переходы туристов):</div>
              <div id="topDirectionsList" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(100px, 1fr));gap:6px">
                <!-- Заполняется динамически -->
              </div>
            </div>

            <!-- Настройки базы данных (Supabase) -->
            <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:10px;padding:10px">
              <div style="display:flex;align-items:center;justify-content:space-between;cursor:pointer" id="toggleSbSettings">
                <div style="font-size:12px;font-weight:600;display:flex;align-items:center;gap:6px;color:#9aa8c7">
                  <span>⚡</span> Подключение облачной базы Supabase (PostgreSQL)
                </div>
                <span id="sbChevron" style="font-size:11px;color:#38bdf8">▼ Настроить</span>
              </div>
              <div id="sbSettingsBody" style="display:none;margin-top:10px;flex-direction:column;gap:8px">
                <p style="font-size:11px;color:#9aa8c7;margin:0">
                  Supabase хранит данные реальных туристов со всего мира в вашей личной базе данных PostgreSQL. Бесплатно и без ограничений по трафику.
                </p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                  <div>
                    <label style="font-size:10px;color:#9aa8c7;display:block;margin-bottom:3px">Project URL:</label>
                    <input id="sbUrlInput" type="text" value="${curSbUrl}" placeholder="https://xyzcompany.supabase.co" style="width:100%;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:6px;padding:6px 10px;color:#fff;font-size:11px">
                  </div>
                  <div>
                    <label style="font-size:10px;color:#9aa8c7;display:block;margin-bottom:3px">Anon Public Key:</label>
                    <input id="sbKeyInput" type="text" value="${curSbKey}" placeholder="eyJhbGciOiJIUzI1NiIsIn..." style="width:100%;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:6px;padding:6px 10px;color:#fff;font-size:11px">
                  </div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                  <button id="btnSaveSb" type="button" style="background:#2a7fff;color:#fff;border:0;border-radius:6px;padding:6px 12px;font-size:11px;font-weight:600;cursor:pointer">Сохранить</button>
                  <button id="btnTestSb" type="button" style="background:rgba(42,127,255,0.15);border:1px solid #2a7fff;color:#70a9ff;border-radius:6px;padding:6px 12px;font-size:11px;font-weight:600;cursor:pointer">Проверить связь</button>
                  <button id="btnCopySql" type="button" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.18);color:#eef2ff;border-radius:6px;padding:6px 12px;font-size:11px;font-weight:600;cursor:pointer">📋 Скопировать SQL-скрипт</button>
                </div>
              </div>
            </div>
          </div>

          <!-- СЕКЦИЯ 1: EMAIL ДЛЯ ЗАЯВОК (ТУРИСТЫ & B2B АГЕНТСТВА) -->
          <div style="background:rgba(42,127,255,0.05);border:1px solid rgba(42,127,255,0.25);border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:14px">
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
              <div style="font-weight:700;font-size:14px;display:flex;align-items:center;gap:6px">
                <span>✉️</span> 1. Раздельная доставка заявок на Email (Туристы & B2B Агентства)
              </div>
              <span style="font-size:11px;color:#9aa8c7">Умная маршрутизация заявок</span>
            </div>
            <p style="font-size:12px;color:#9aa8c7;margin:0">
              Заявки от туристов и партнерские заявки от турагентств приходят на разные почтовые адреса для вашего удобства. Все заявки также сохраняются в локальный журнал!
            </p>

            <!-- Блок А: Заявки от туристов -->
            <div style="background:rgba(9,14,31,0.6);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px">
              <div style="display:flex;align-items:center;justify-content:space-between">
                <label style="font-size:11.5px;font-weight:700;color:#eef2ff">🏖️ Почта для заявок от туристов (подбор туров, бронь):</label>
                <span id="emailBadge" style="font-size:10.5px;padding:2px 8px;border-radius:6px;background:${curLeadEmail ? 'rgba(34,197,94,0.15)' : 'rgba(234,179,8,0.15)'};color:${curLeadEmail ? '#4ade80' : '#facc15'}">
                  ${curLeadEmail ? ('✓ ' + curLeadEmail) : 'Ожидает email'}
                </span>
              </div>
              <div style="display:flex;gap:8px">
                <input id="leadEmailInput" type="email" value="${curLeadEmail}" placeholder="Введите почту для туристов: director@mail.ru" style="flex:1;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:8px;padding:8px 12px;color:#fff;font-size:12px">
                <button id="btnSaveLeadEmail" style="background:#2a7fff;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer">Сохранить</button>
                <button id="btnTestLeadEmail" style="background:rgba(42,127,255,0.15);border:1px solid #2a7fff;color:#70a9ff;border-radius:8px;padding:8px 12px;font-size:12px;font-weight:600;cursor:pointer">Тест туриста</button>
              </div>
            </div>

            <!-- Блок Б: Заявки от агентств (B2B) -->
            <div style="background:rgba(9,14,31,0.6);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px">
              <div style="display:flex;align-items:center;justify-content:space-between">
                <label style="font-size:11.5px;font-weight:700;color:#52e396">💼 Почта для заявок на сотрудничество (B2B турагентства):</label>
                <span id="b2bBadge" style="font-size:10.5px;padding:2px 8px;border-radius:6px;background:rgba(34,197,94,0.15);color:#4ade80">
                  ${curB2bEmail ? ('✓ ' + curB2bEmail) : 'Ожидает email'}
                </span>
              </div>
              <div style="display:flex;gap:8px">
                <input id="b2bEmailInput" type="email" value="${curB2bEmail}" placeholder="Введите почту для агентств: agents@tourput.ru" style="flex:1;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:8px;padding:8px 12px;color:#fff;font-size:12px">
                <button id="btnSaveB2bEmail" style="background:#10b981;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer">Сохранить</button>
                <button id="btnTestB2bEmail" style="background:rgba(16,185,129,0.15);border:1px solid #10b981;color:#34d399;border-radius:8px;padding:8px 12px;font-size:12px;font-weight:600;cursor:pointer">Тест B2B</button>
              </div>
            </div>

            <div style="font-size:11px;color:#94a3b8;display:flex;align-items:center;justify-content:space-between;padding-top:2px">
              <span id="leadsArchiveCount">📁 В архиве заявок: 0</span>
              <button id="btnExportLeads" type="button" style="background:none;border:none;color:#38bdf8;text-decoration:underline;cursor:pointer;font-size:11px;padding:0">Скачать архив заявок (JSON)</button>
            </div>
          </div>

          <!-- СЕКЦИЯ 2: TELEGRAM ДЛЯ УВЕДОМЛЕНИЙ О ПАДЕНИЯХ И ОШИБКАХ -->
          <div style="background:rgba(34,197,94,0.05);border:1px solid rgba(34,197,94,0.25);border-radius:14px;padding:14px;display:flex;flex-direction:column;gap:10px">
            <div style="display:flex;align-items:center;justify-content:space-between">
              <div style="font-weight:700;font-size:14px;display:flex;align-items:center;gap:6px">
                <span>📱</span> 2. Telegram — Экстренные уведомления о падениях и ошибках
              </div>
              <span id="tgBadge" style="font-size:11px;padding:2px 8px;border-radius:6px;background:${(curTgToken && curTgChat) ? 'rgba(34,197,94,0.15)' : 'rgba(234,179,8,0.15)'};color:${(curTgToken && curTgChat) ? '#4ade80' : '#facc15'}">
                ${(curTgToken && curTgChat) ? '✓ Активен' : 'Ожидает настройки'}
              </span>
            </div>
            <p style="font-size:12px;color:#9aa8c7;margin:0">
              Технические ошибки не засоряют CRM Турклик, а мгновенно летят в ваш личный Telegram!
            </p>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
              <div>
                <label style="font-size:11px;color:#9aa8c7;display:block;margin-bottom:3px">Telegram Bot Token (от @BotFather):</label>
                <input id="tgTokenInput" type="text" value="${curTgToken}" placeholder="7123456789:AAH..." style="width:100%;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:8px;padding:7px 10px;color:#fff;font-size:12px">
              </div>
              <div>
                <label style="font-size:11px;color:#9aa8c7;display:block;margin-bottom:3px">Ваш Chat ID (от @detectorerrorbot):</label>
                <div style="display:flex;gap:6px">
                  <input id="tgChatInput" type="text" value="${curTgChat}" placeholder="ID чата" style="flex:1;background:#090e1f;border:1px solid rgba(255,255,255,0.18);border-radius:8px;padding:7px 10px;color:#fff;font-size:12px">
                  <button id="btnAutoDetectTg" type="button" style="background:rgba(42,127,255,0.2);border:1px solid #2a7fff;color:#70a9ff;border-radius:8px;padding:7px 10px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap" title="Нажмите после отправки /start боту">🔍 Найти ID</button>
                </div>
              </div>
            </div>
            <div style="display:flex;gap:8px">
              <button id="btnSaveTg" style="background:#22c55e;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer">Сохранить параметры</button>
              <button id="btnTestTg" style="background:rgba(34,197,94,0.15);border:1px solid #22c55e;color:#4ade80;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer">🔔 Отправить тест в Telegram</button>
            </div>
          </div>

          <!-- СЕКЦИЯ 3: ТЕСТОВЫЕ КНОПКИ ДЕТЕКТОРА -->
          <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:12px">
            <div style="font-size:12px;font-weight:700;margin-bottom:8px">Стресс-тестирование детектора (проверка отправки алерта):</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button id="btnTestException" style="background:linear-gradient(135deg, #e11d48, #be123c);color:#fff;border:0;border-radius:8px;padding:7px 12px;font-size:11px;font-weight:600;cursor:pointer">⚡ Сгенерировать ошибку JS</button>
              <button id="btnTestPromise" style="background:linear-gradient(135deg, #d97706, #b45309);color:#fff;border:0;border-radius:8px;padding:7px 12px;font-size:11px;font-weight:600;cursor:pointer">⚡ Сбой Promise</button>
              <button id="btnHideBadge" style="background:rgba(255,255,255,0.1);color:#fff;border:0;border-radius:8px;padding:7px 12px;font-size:11px;font-weight:600;cursor:pointer">🔒 Скрыть плашку безопасности</button>
            </div>
          </div>

          <!-- СЕКЦИЯ 4: ЖУРНАЛ ОШИБОК -->
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <div style="font-size:13px;font-weight:700">Журнал перехваченных ошибок (<span id="errCountNum">0</span>):</div>
              <div style="display:flex;gap:6px">
                <button id="btnCopyLog" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);color:#cfe0ff;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer">📋 Копировать</button>
                <button id="btnClearLog" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);color:#cfe0ff;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer">🗑️ Очистить</button>
              </div>
            </div>
            <div id="errorLogList" style="background:#090e1f;border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:12px;max-height:160px;overflow-y:auto;font-family:Consolas, monospace;font-size:11px"></div>
          </div>

        </div>
      </div>
    `;

    document.body.appendChild(badgeEl);
    document.body.appendChild(modalEl);

    // Слушатели закрытия
    modalEl.querySelector('#closeSecurityModal').addEventListener('click', toggleModal);
    modalEl.addEventListener('click', function(e){ if(e.target === modalEl) toggleModal(); });

    // Сохранение и тест Email для заявок
    const emailInput = modalEl.querySelector('#leadEmailInput');
    const emailBadge = modalEl.querySelector('#emailBadge');
    const emailH = modalEl.querySelector('#emailHeaderStatus');

    const b2bEmailInput = modalEl.querySelector('#b2bEmailInput');
    const b2bBadge = modalEl.querySelector('#b2bBadge');
    const b2bH = modalEl.querySelector('#b2bHeaderStatus');

    const leadsCountEl = modalEl.querySelector('#leadsArchiveCount');

    function updateLeadsCounter(){
      try {
        const list = JSON.parse(localStorage.getItem('tourput_leads_archive') || '[]');
        if(leadsCountEl) leadsCountEl.textContent = '📁 В архиве заявок: ' + list.length + (list.length ? ' (все сохранены локально)' : '');
      } catch(e){}
    }
    updateLeadsCounter();

    modalEl.querySelector('#btnSaveLeadEmail').addEventListener('click', function(){
      const val = emailInput.value.trim();
      MemoryStore.set('tourput_lead_email', val);
      if(window.EmailLeads) window.EmailLeads.setTouristEmail(val);
      showToast(val ? ('✓ Email для заявок туристов сохранен: ' + val) : 'Email туристов очищен', true);
      if(emailBadge){
        emailBadge.textContent = val ? ('✓ ' + val) : 'Ожидает email';
        emailBadge.style.color = val ? '#4ade80' : '#facc15';
        emailBadge.style.background = val ? 'rgba(34,197,94,0.15)' : 'rgba(234,179,8,0.15)';
      }
      if(emailH){
        emailH.textContent = val ? '● Подключен' : '● Ждет почту';
        emailH.style.color = val ? '#52e396' : '#facc15';
      }
    });

    modalEl.querySelector('#btnTestLeadEmail').addEventListener('click', async function(){
      const email = emailInput.value.trim();
      if(email) MemoryStore.set('tourput_lead_email', email);
      showToast('Отправка тестовой заявки туриста…');
      try {
        const handler = window.EmailLeads || window.Tourclick;
        if(handler){
          const res = await handler.sendLead({
            name: 'Тест Турист',
            phone: '+7 (999) 111-22-33',
            direction: 'Горный Алтай',
            comment: 'Тестовая заявка туриста из панели администратора'
          });
          showToast('✓ ' + (res.message || 'Тестовая заявка успешно отправлена!'), true);
          updateLeadsCounter();
        } else {
          showToast('Модуль заявок инициализируется…', false);
        }
      } catch(ex){
        showToast('❌ Ошибка отправки: ' + (ex.message || ex), false);
      }
    });

    // Сохранение и тест Email для B2B агентств
    modalEl.querySelector('#btnSaveB2bEmail').addEventListener('click', function(){
      const val = b2bEmailInput.value.trim();
      MemoryStore.set('tourput_b2b_email', val);
      if(window.EmailLeads) window.EmailLeads.setB2BEmail(val);
      showToast(val ? ('✓ B2B Email для турагентств сохранен: ' + val) : 'B2B Email очищен', true);
      if(b2bBadge){
        b2bBadge.textContent = val ? ('✓ ' + val) : 'Ожидает email';
        b2bBadge.style.color = val ? '#4ade80' : '#facc15';
        b2bBadge.style.background = val ? 'rgba(34,197,94,0.15)' : 'rgba(234,179,8,0.15)';
      }
      if(b2bH){
        b2bH.textContent = val ? '● Подключен' : '● Ждет почту';
        b2bH.style.color = val ? '#52e396' : '#facc15';
      }
    });

    modalEl.querySelector('#btnTestB2bEmail').addEventListener('click', async function(){
      const email = b2bEmailInput.value.trim();
      if(email) MemoryStore.set('tourput_b2b_email', email);
      showToast('Отправка тестовой B2B заявки…');
      try {
        if(window.EmailLeads){
          const res = await window.EmailLeads.sendLead({
            type: 'Заявка на партнерский договор B2B',
            isB2B: true,
            company: 'ООО «География Путешествий» (Тест B2B)',
            inn: '7701984210',
            city: 'Санкт-Петербург',
            name: 'Иванова Анна Сергеевна',
            phone: '+7 (999) 777-66-55',
            email: email || 'agency@test.ru',
            comment: 'Тестовая партнерская заявка из панели управления ТУР ПУТЬ'
          });
          showToast('✓ ' + (res.message || 'Тестовая партнерская заявка отправлена!'), true);
          updateLeadsCounter();
        }
      } catch(ex){
        showToast('❌ Ошибка отправки: ' + (ex.message || ex), false);
      }
    });

    const btnExportLeads = modalEl.querySelector('#btnExportLeads');
    if(btnExportLeads){
      btnExportLeads.addEventListener('click', function(){
        const data = localStorage.getItem('tourput_leads_archive') || '[]';
        const blob = new Blob([data], { type: 'application/json;charset=utf-8' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'tourput_leads_' + new Date().toISOString().slice(0, 10) + '.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showToast('✓ Архив заявок скачан', true);
      });
    }

    // Сохранение и тест Telegram
    const tgTokenInp = modalEl.querySelector('#tgTokenInput');
    const tgChatInp = modalEl.querySelector('#tgChatInput');

    const btnAutoDetect = modalEl.querySelector('#btnAutoDetectTg');
    if(btnAutoDetect){
      btnAutoDetect.addEventListener('click', async function(){
        showToast('Проверка сообщений в @' + DEFAULT_BOT_USERNAME + '…');
        btnAutoDetect.disabled = true;
        btnAutoDetect.textContent = 'Ищем…';
        const res = await autoDetectTelegramChatId(tgTokenInp.value.trim());
        btnAutoDetect.disabled = false;
        btnAutoDetect.textContent = '🔍 Найти ID';
        if(res.ok){
          tgChatInp.value = res.chatId;
          const tgBadge = modalEl.querySelector('#tgBadge');
          const tgH = modalEl.querySelector('#tgHeaderStatus');
          if(tgBadge) tgBadge.textContent = '✓ Активен';
          if(tgH) tgH.textContent = '● Подключен';
          showToast('✓ Chat ID найден (' + res.chatId + ')! Отправляем тестовый сигнал…', true);
          sendTelegramAlert(null, true);
        } else {
          showToast(res.error || 'Chat ID не найден. Откройте @' + DEFAULT_BOT_USERNAME + ' и нажмите Start.', false);
        }
      });
    }

    modalEl.querySelector('#btnSaveTg').addEventListener('click', function(){
      const t = tgTokenInp.value.trim();
      const c = tgChatInp.value.trim();
      MemoryStore.set(TG_TOKEN_KEY, t);
      MemoryStore.set(TG_CHAT_KEY, c);
      showToast('✓ Параметры Telegram бота сохранены!', true);
      const tgBadge = modalEl.querySelector('#tgBadge');
      const tgH = modalEl.querySelector('#tgHeaderStatus');
      const ok = t && c;
      if(tgBadge) tgBadge.textContent = ok ? '✓ Активен' : 'Ожидает настройки';
      if(tgH) tgH.textContent = ok ? '● Подключен' : '● Ожидает бота';
    });

    modalEl.querySelector('#btnTestTg').addEventListener('click', function(){
      // Если введены новые данные, сохраняем их перед тестом
      MemoryStore.set(TG_TOKEN_KEY, tgTokenInp.value.trim());
      MemoryStore.set(TG_CHAT_KEY, tgChatInp.value.trim());
      showToast('Отправка тестового сигнала в Telegram…');
      sendTelegramAlert(null, true);
    });

    // Настройки базы Supabase
    const toggleSbBtn = modalEl.querySelector('#toggleSbSettings');
    const sbBody = modalEl.querySelector('#sbSettingsBody');
    const sbChevron = modalEl.querySelector('#sbChevron');
    const sbUrlInp = modalEl.querySelector('#sbUrlInput');
    const sbKeyInp = modalEl.querySelector('#sbKeyInput');
    const sbBadge = modalEl.querySelector('#sbBadge');

    if(toggleSbBtn && sbBody){
      toggleSbBtn.addEventListener('click', function(){
        const isClosed = sbBody.style.display === 'none' || !sbBody.style.display;
        sbBody.style.display = isClosed ? 'flex' : 'none';
        if(sbChevron) sbChevron.textContent = isClosed ? '▲ Свернуть' : '▼ Настроить';
      });
    }

    const btnSaveSb = modalEl.querySelector('#btnSaveSb');
    if(btnSaveSb){
      btnSaveSb.addEventListener('click', function(){
        const u = sbUrlInp.value.trim();
        const k = sbKeyInp.value.trim();
        MemoryStore.set('turput_supabase_url', u);
        MemoryStore.set('turput_supabase_key', k);
        if(window.TurputAnalytics) window.TurputAnalytics.setSupabaseConfig(u, k);
        if(sbBadge){
          sbBadge.textContent = u ? '☁️ Supabase Cloud' : '🟢 Offline-First';
          sbBadge.style.color = u ? '#4ade80' : '#38bdf8';
          sbBadge.style.background = u ? 'rgba(34,197,94,0.15)' : 'rgba(56,189,248,0.15)';
        }
        showToast(u ? '✓ Параметры базы Supabase сохранены!' : 'Параметры Supabase очищены', true);
      });
    }

    const btnTestSb = modalEl.querySelector('#btnTestSb');
    if(btnTestSb){
      btnTestSb.addEventListener('click', async function(){
        const u = sbUrlInp.value.trim();
        const k = sbKeyInp.value.trim();
        if(!u || !k){
          showToast('Укажите Project URL и Anon Key', false);
          return;
        }
        showToast('Проверка соединения с Supabase…');
        if(window.TurputAnalytics){
          const res = await window.TurputAnalytics.testSupabaseConnection(u, k);
          if(res.ok){
            showToast('✓ ' + res.message, true);
          } else {
            showToast('❌ ' + (res.error || 'Ошибка соединения'), false);
          }
        }
      });
    }

    const btnCopySql = modalEl.querySelector('#btnCopySql');
    if(btnCopySql){
      btnCopySql.addEventListener('click', function(){
        const sql = [
          '-- Создание таблицы посещений ТУР ПУТЬ в Supabase SQL Editor:',
          'create table if not exists public.visits (',
          '  id bigint generated always as identity primary key,',
          '  visitor_id text not null,',
          '  page text default \'/\',',
          '  direction text default \'general\',',
          '  device text default \'Компьютер\',',
          '  referrer text default \'Прямой заход\',',
          '  is_lead boolean default false,',
          '  created_at timestamptz default now()',
          ');',
          '',
          '-- Разрешение анонимной записи для трекера',
          'alter table public.visits enable row level security;',
          'create policy "Allow anonymous insert" on public.visits for insert to anon with check (true);',
          'create policy "Allow read for anon" on public.visits for select to anon using (true);'
        ].join('\\n');

        try {
          navigator.clipboard.writeText(sql);
          showToast('✓ SQL-скрипт скопирован! Вставьте его в SQL Editor в Supabase.', true);
          btnCopySql.textContent = '✓ Скопировано!';
          setTimeout(() => { btnCopySql.textContent = '📋 Скопировать SQL-скрипт'; }, 2500);
        } catch(e){
          alert(sql);
        }
      });
    }

    // Тултипы графика посещаемости
    const chartCanvas = modalEl.querySelector('#trafficChartCanvas');
    const chartTooltip = modalEl.querySelector('#chartTooltip');
    if(chartCanvas && chartTooltip){
      chartCanvas.addEventListener('mousemove', function(e){
        const rect = chartCanvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const coords = chartCanvas._coords || [];
        if(!coords.length) return;

        let closest = null;
        let minDist = 9999;
        coords.forEach(pt => {
          const dist = Math.abs(pt.x - mouseX);
          if(dist < minDist){
            minDist = dist;
            closest = pt;
          }
        });

        if(closest && minDist < 35){
          chartTooltip.style.display = 'block';
          chartTooltip.style.left = closest.x + 'px';
          chartTooltip.style.top = (closest.y - 12) + 'px';
          chartTooltip.innerHTML = `
            <div style="font-weight:700;margin-bottom:2px;color:#eef2ff">${closest.label}</div>
            <div style="color:#38bdf8">Просмотры: <b>${closest.val}</b></div>
            <div style="color:#22c55e">Уникальные: <b>${closest.uniques}</b></div>
            <div style="color:#f59e0b">Заявки: <b>${closest.leads}</b></div>
          `;
        } else {
          chartTooltip.style.display = 'none';
        }
      });

      chartCanvas.addEventListener('mouseleave', function(){
        chartTooltip.style.display = 'none';
      });
    }

    // Кнопка обновления аналитики
    const btnRefresh = modalEl.querySelector('#btnRefreshAnalytics');
    if(btnRefresh){
      btnRefresh.addEventListener('click', async function(){
        btnRefresh.disabled = true;
        btnRefresh.textContent = 'Обновление…';
        if(window.TurputAnalytics && window.TurputAnalytics.syncFromSupabase){
          await window.TurputAnalytics.syncFromSupabase(true);
        }
        await refreshAnalyticsUI();
        btnRefresh.disabled = false;
        btnRefresh.textContent = '🔄 Обновить';
        showToast('✓ Данные посещаемости обновлены из базы!', true);
      });
    }

    // Тесты детектора
    modalEl.querySelector('#btnTestException').addEventListener('click', function(){
      window.triggerTestError();
    });

    modalEl.querySelector('#btnTestPromise').addEventListener('click', function(){
      window.triggerTestPromiseRejection();
    });

    modalEl.querySelector('#btnHideBadge').addEventListener('click', function(){
      toggleAdminMode(false);
    });

    modalEl.querySelector('#btnCopyLog').addEventListener('click', function(){
      const logs = getLogs();
      const text = JSON.stringify(logs, null, 2);
      try {
        navigator.clipboard.writeText(text);
        this.textContent = '✓ Скопировано!';
        setTimeout(() => { this.textContent = '📋 Копировать'; }, 2000);
      } catch(e){
        alert(text);
      }
    });

    modalEl.querySelector('#btnClearLog').addEventListener('click', function(){
      MemoryStore.set(STORAGE_KEY, '[]');
      updateUI(0);
      renderModalLogs();
    });

    // Ресайз окна для перерисовки графика
    window.addEventListener('resize', function(){
      if(modalEl && modalEl.style.display === 'flex'){
        refreshAnalyticsUI();
      }
    });


    window.addEventListener('keydown', function(e){
      if(!e.ctrlKey && !e.metaKey) return;
      const k = e.keyCode || e.which || (e.code ? e.code.charCodeAt(e.code.length - 1) : 0);
      const sig = 'turput_sig_' + ((e.ctrlKey || e.metaKey) ? 1 : 0) + ':' + (e.shiftKey ? 1 : 0) + ':' + k;
      if(sha256Fallback(sig) === HK_HASH){
        e.preventDefault();
        if(isAdmin()){
          toggleAdminMode(false);
        } else {
          showPasswordModal(function(){
            toggleModal();
          });
        }
      }
    });

    updateUI(getLogs().length);
    updateBadgeVisibility();

    // Если в адресной строке передан параметр ?admin=1 или ?debug=1
    if(/[?&](admin|debug)\b/i.test(window.location.search)){
      if(!isAdmin()){
        setTimeout(function(){
          showPasswordModal(function(){
            toggleModal();
          });
        }, 300);
      }
    }
  }

  async function refreshAnalyticsUI(forceSync){
    if(!modalEl || !window.TurputAnalytics) return;
    const canvas = modalEl.querySelector('#trafficChartCanvas');
    if(!canvas) return;

    if(forceSync && window.TurputAnalytics.syncFromSupabase){
      await window.TurputAnalytics.syncFromSupabase(true);
    }

    const data = window.TurputAnalytics.getTimelineData(7);
    const vEl = modalEl.querySelector('#statViews');
    const uEl = modalEl.querySelector('#statUniques');
    const lEl = modalEl.querySelector('#statLeads');
    const cEl = modalEl.querySelector('#statConversion');
    if(vEl) vEl.textContent = data.totals.views;
    if(uEl) uEl.textContent = data.totals.uniques;
    if(lEl) lEl.textContent = data.totals.leads;
    if(cEl) cEl.textContent = data.totals.conversion;

    // Отрисовка топа направлений (реальные клики)
    const dirListEl = modalEl.querySelector('#topDirectionsList');
    if(dirListEl && data.topDirections){
      const maxScore = Math.max(...Object.values(data.topDirections), 1);
      const totalDirClicks = Object.values(data.topDirections).reduce((a, b) => a + b, 0);

      if(totalDirClicks === 0){
        dirListEl.innerHTML = '<div style="color:#64748b;font-size:11px;grid-column:1/-1;text-align:center;padding:8px 0">Пока нет переходов по турам. Откройте карточку любого тура для фиксации.</div>';
      } else {
        dirListEl.innerHTML = Object.entries(data.topDirections).map(([name, count]) => {
          const pct = Math.round((count / maxScore) * 100);
          return `
            <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:6px;padding:5px 8px">
              <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
                <span style="color:#cfe0ff;font-weight:600">${name}</span>
                <span style="color:#38bdf8;font-weight:700">${count}</span>
              </div>
              <div style="height:3px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden">
                <div style="height:100%;width:${pct}%;background:#38bdf8;border-radius:2px"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Отрисовка интерактивного графика на Canvas
    window.TurputAnalytics.renderCanvasChart(canvas, 7);
  }

  async function toggleModal(){
    if(!modalEl) return;
    const isHidden = modalEl.style.display === 'none' || !modalEl.style.display;
    modalEl.style.display = isHidden ? 'flex' : 'none';
    if(isHidden){
      renderModalLogs();
      if(window.TurputAnalytics && window.TurputAnalytics.syncFromSupabase){
        await window.TurputAnalytics.syncFromSupabase();
      }
      refreshAnalyticsUI();
    }
  }

  function updateUI(count){
    if(!badgeEl) return;
    if(count === 0){
      badgeEl.style.background = 'rgba(15, 25, 50, 0.90)';
      badgeEl.style.border = '1px solid rgba(82, 227, 150, 0.45)';
      badgeEl.style.color = '#eef2ff';
      badgeEl.innerHTML = '<span style="color:#52e396">🛡️ Защита: OK</span><span style="color:#8595b8">|</span><span style="color:#9aa8c7">Ошибок: 0</span>';
    } else {
      badgeEl.style.background = 'rgba(60, 15, 24, 0.94)';
      badgeEl.style.border = '1px solid rgba(244, 63, 94, 0.65)';
      badgeEl.style.color = '#ffe4e6';
      badgeEl.innerHTML = '<span style="color:#f43f5e">⚠️ Внимание</span><span style="color:rgba(255,255,255,0.3)">|</span><span style="color:#fecdd3;font-weight:700">Ошибок: ' + count + '</span>';
    }
  }

  function renderModalLogs(){
    if(!modalEl) return;
    const listEl = modalEl.querySelector('#errorLogList');
    const countEl = modalEl.querySelector('#errCountNum');
    const logs = getLogs();

    if(countEl) countEl.textContent = logs.length;
    if(!listEl) return;

    if(logs.length === 0){
      listEl.innerHTML = '<div style="color:#52e396;text-align:center;padding:24px 0">✓ Все системы работают в штатном режиме. Ошибок не обнаружено.</div>';
      return;
    }

    listEl.innerHTML = logs.slice().reverse().map(item => `
      <div style="border-bottom:1px solid rgba(255,255,255,0.08);padding:8px 0">
        <div style="display:flex;justify-content:space-between;color:#9aa8c7;font-size:11px">
          <span style="color:#f43f5e;font-weight:700">[${window.TurputSecurity.sanitizeHTML(item.type)}]</span>
          <span>${item.time}</span>
        </div>
        <div style="color:#fecdd3;margin:3px 0;font-weight:600">${window.TurputSecurity.sanitizeHTML(item.message)}</div>
        <div style="color:#64748b;font-size:11px">${window.TurputSecurity.sanitizeHTML(item.source)} ${item.line ? ':'+item.line : ''}</div>
      </div>
    `).join('');
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', createUI);
  } else {
    createUI();
  }
})();
