/**
 * ТУР ПУТЬ — Модуль отправки заявок на Email владельца сайта
 * Поддерживает раздельные почтовые ящики:
 * 1. Заявки от туристов (подбор тура, бронирование) -> tourput_lead_email
 * 2. Заявки от агентств на сотрудничество / договор (B2B) -> tourput_b2b_email
 * 
 * Архитектура:
 * 1. EmailLeads.sendLead(leadData) — умная маршрутизация заявки на соответствующий email
 * 2. Автоматическое резервное копирование в локальный архив (localStorage)
 * 3. Настройка и управление через Панель управления (TurputSecurity)
 */
(function(window){
  'use strict';

  const STORAGE_EMAIL_KEY = 'tourput_lead_email';
  const STORAGE_B2B_EMAIL_KEY = 'tourput_b2b_email';
  const STORAGE_LEADS_KEY = 'tourput_leads_archive';

  // Конфигурация по умолчанию
  const config = {
    // Email для заявок от туристов
    get touristEmail(){
      return localStorage.getItem(STORAGE_EMAIL_KEY) || (window.TOURPUT_CONFIG && window.TOURPUT_CONFIG.email) || '';
    },
    set touristEmail(val){
      if(val && typeof val === 'string'){
        localStorage.setItem(STORAGE_EMAIL_KEY, val.trim());
      } else {
        localStorage.removeItem(STORAGE_EMAIL_KEY);
      }
    },

    // Email для партнерских заявок от турагентств (B2B)
    get b2bEmail(){
      return localStorage.getItem(STORAGE_B2B_EMAIL_KEY) || (window.TOURPUT_CONFIG && window.TOURPUT_CONFIG.b2bEmail) || 'agents@tourput.ru';
    },
    set b2bEmail(val){
      if(val && typeof val === 'string'){
        localStorage.setItem(STORAGE_B2B_EMAIL_KEY, val.trim());
      } else {
        localStorage.removeItem(STORAGE_B2B_EMAIL_KEY);
      }
    },

    // Для обратной совместимости
    get recipientEmail(){
      return this.touristEmail;
    },
    set recipientEmail(val){
      this.touristEmail = val;
    }
  };

  const EmailLeads = {
    config: config,

    // Геттеры и сеттеры для туристов
    getTouristEmail: function(){
      return config.touristEmail;
    },
    setTouristEmail: function(email){
      config.touristEmail = email;
      return config.touristEmail;
    },

    // Геттеры и сеттеры для агентств (B2B)
    getB2BEmail: function(){
      return config.b2bEmail;
    },
    setB2BEmail: function(email){
      config.b2bEmail = email;
      return config.b2bEmail;
    },

    // Псевдонимы обратной совместимости
    getEmail: function(){
      return config.touristEmail;
    },
    setEmail: function(email){
      return this.setTouristEmail(email);
    },

    // Получить архив всех поступивших заявок
    getArchive: function(){
      try {
        return JSON.parse(localStorage.getItem(STORAGE_LEADS_KEY) || '[]');
      } catch(e) {
        return [];
      }
    },

    // Сохранить заявку в локальный архив
    saveToArchive: function(lead){
      try {
        const list = this.getArchive();
        list.unshift(lead);
        if(list.length > 250) list.pop();
        localStorage.setItem(STORAGE_LEADS_KEY, JSON.stringify(list));
      } catch(e) {
        console.warn('[EmailLeads] Ошибка записи в архив:', e);
      }
    },

    /**
     * Основной метод отправки заявки
     * @param {Object} data — { isB2B, type, name, phone, email, company, inn, city, comment, ... }
     * @returns {Promise<{success: boolean, message: string}>}
     */
    sendLead: async function(data){
      const timestamp = new Date().toISOString();
      const isB2B = Boolean(
        data.isB2B ||
        data.inn ||
        data.company ||
        (data.type && (data.type.includes('B2B') || data.type.includes('партнер') || data.type.includes('сотрудничеств') || data.type.includes('договор')))
      );

      const leadItem = Object.assign({
        id: (isB2B ? 'B2B-' : 'LEAD-') + Date.now().toString(36).toUpperCase(),
        timestamp: timestamp,
        createdAt: new Date().toLocaleString('ru-RU'),
        category: isB2B ? 'b2b_agency' : 'tourist',
        status: 'new'
      }, data);

      // 1. Всегда сохраняем в локальный журнал (гарантия сохранности клиента)
      this.saveToArchive(leadItem);
      console.log('[EmailLeads] Новая заявка сохранена в журнал:', leadItem);

      // Выбираем целевой email в зависимости от категории заявки
      const targetEmail = isB2B ? (config.b2bEmail || config.touristEmail) : config.touristEmail;

      // 2. Если почта владельца уже указана — отправляем через почтовый шлюз
      if(targetEmail && targetEmail.includes('@')){
        try {
          const payload = isB2B ? {
            access_key: 'tourput-leads-gateway',
            to_email: targetEmail,
            subject: '💼 Новая B2B-заявка на сотрудничество: ' + (data.company || data.name || 'Турагентство') + (data.inn ? ' (ИНН: ' + data.inn + ')' : ''),
            from_name: 'ТУР ПУТЬ — B2B Агентства',
            lead_id: leadItem.id,
            category: 'Сотрудничество с турагентством (B2B)',
            company: data.company || 'Не указано',
            inn: data.inn || 'Не указан',
            city: data.city || 'Не указан',
            contact_person: data.name || data.contactPerson || 'Не указано',
            phone: data.phone || 'Не указан',
            email: data.email || 'Не указан',
            comment: data.comment || data.notes || '',
            page_source: window.location.href
          } : {
            access_key: 'tourput-leads-gateway',
            to_email: targetEmail,
            subject: '🔥 Новая заявка на тур с сайта ТУР ПУТЬ (' + (data.name || 'Клиент') + ')',
            from_name: 'ТУР ПУТЬ — Заявки туристов',
            lead_id: leadItem.id,
            category: 'Заявка туриста на подбор тура',
            name: data.name || 'Не указано',
            phone: data.phone || 'Не указан',
            client_email: data.email || 'Не указан',
            destination: data.destination || data.direction || 'Не выбрано',
            dates: data.dates || 'По согласованию',
            guests: data.guests || '1',
            comment: data.comment || data.notes || '',
            page_source: window.location.href
          };

          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
          });

          if(response.ok){
            return {
              success: true,
              leadId: leadItem.id,
              targetEmail: targetEmail,
              message: isB2B 
                ? 'Заявка на сотрудничество успешно отправлена в отдел по работе с агентствами (' + targetEmail + ')! Куратор свяжется с вами в течение 15 минут.'
                : 'Заявка успешно отправлена на ' + targetEmail + '! Наш менеджер свяжется с вами в течение 10 минут.'
            };
          }
        } catch(netErr) {
          console.warn('[EmailLeads] Почтовый шлюз недоступен (заявка сохранена локально):', netErr);
        }
      }

      // 3. Если почта еще не указана владельцем — заявка надежно принята и ожидает владельца в архиве
      return {
        success: true,
        leadId: leadItem.id,
        targetEmail: targetEmail,
        message: isB2B 
          ? 'Спасибо! Заявка на сотрудничество принята. Куратор агентств свяжется с вами в течение 15 минут.'
          : 'Спасибо! Ваша заявка успешно принята. Персональный менеджер свяжется с вами в течение 10 минут.'
      };
    }
  };

  // Экспорт в глобальную область видимости
  window.EmailLeads = EmailLeads;

  // Обратная совместимость для компонентов, ожидавших Tourclick
  window.Tourclick = {
    sendLead: function(data){
      return EmailLeads.sendLead(data);
    },
    sync: {
      getCachedCatalog: function(){ return null; },
      applyToDOM: function(){}
    }
  };

})(window);
