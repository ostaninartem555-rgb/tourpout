// Меню, reveal-анимация, активный пункт, год, переключатель темы, каталог, телефоны и соцсети
(function(){
  // Инициализация темы (по умолчанию светлая с белым основным фоном)
  function getSavedTheme(){
    try {
      return localStorage.getItem('theme') || localStorage.getItem('tourputh_theme') || localStorage.getItem('tourput_theme') || 'light';
    } catch(e){
      return 'light';
    }
  }

  function saveTheme(theme){
    try {
      localStorage.setItem('theme', theme);
      localStorage.setItem('tourputh_theme', theme);
      localStorage.setItem('tourput_theme', theme);
    } catch(e){}
  }

  function applyTheme(theme){
    const isDark = (theme === 'dark');
    if(isDark){
      document.documentElement.setAttribute('data-theme', 'dark');
      if(document.body) document.body.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
      if(document.body) document.body.removeAttribute('data-theme');
    }
    const wrapper = document.getElementById('viewportWrapper');
    if(wrapper){
      if(isDark) wrapper.setAttribute('data-theme', 'dark');
      else wrapper.removeAttribute('data-theme');
    }
    updateThemeBtn();
  }

  const savedTheme = getSavedTheme();
  let queryTheme = '';
  try {
    const p = new URLSearchParams(window.location.search);
    queryTheme = p.get('theme');
  } catch(e){}
  const activeInitial = (queryTheme === 'dark' || queryTheme === 'light') ? queryTheme : (savedTheme === 'dark' ? 'dark' : 'light');
  applyTheme(activeInitial);

  // Кнопка переключения темы
  const themeBtn = document.getElementById('themeToggle');
  function updateThemeBtn(){
    const btn = document.getElementById('themeToggle');
    if(!btn) return;
    const isDark = (document.documentElement.getAttribute('data-theme') === 'dark' || (document.body && document.body.getAttribute('data-theme') === 'dark'));
    btn.innerHTML = isDark ? '&#9728;&#65039;' : '&#127769;'; // ☀️ / 🌙
    btn.title = isDark ? 'Включить светлую тему' : 'Включить темную тему';
    btn.setAttribute('aria-label', btn.title);
  }
  updateThemeBtn();

  if(themeBtn){
    themeBtn.addEventListener('click', function(e){
      e.preventDefault();
      const isDark = (document.documentElement.getAttribute('data-theme') === 'dark' || (document.body && document.body.getAttribute('data-theme') === 'dark'));
      const nextTheme = isDark ? 'light' : 'dark';
      saveTheme(nextTheme);
      applyTheme(nextTheme);
    });
  }

  // Мобильное меню
  const b = document.getElementById('burger');
  const l = document.getElementById('navLinks');
  if(b && l) b.addEventListener('click', ()=> l.classList.toggle('open'));

  // Панель каталога (Каталог туров)
  const catBtn = document.getElementById('catalogBtn');
  const catPanel = document.getElementById('catalogPanel');
  if(catBtn && catPanel){
    function toggleCatalog(forceState){
      const willOpen = (typeof forceState === 'boolean') ? forceState : !catPanel.classList.contains('show');
      catPanel.classList.toggle('show', willOpen);
      catBtn.classList.toggle('active', willOpen);
      catBtn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    }
    catBtn.addEventListener('click', function(e){
      e.stopPropagation();
      toggleCatalog();
    });
    document.addEventListener('click', function(e){
      if(!catPanel.contains(e.target) && !catBtn.contains(e.target)){
        toggleCatalog(false);
      }
    });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape') toggleCatalog(false);
    });

    // Быстрый подбор тура из панели каталога
    const catSearchBtn = document.getElementById('catSearchBtn');
    if(catSearchBtn){
      catSearchBtn.addEventListener('click', function(){
        const toSelect = document.getElementById('catSearchTo');
        const dest = toSelect ? toSelect.value : 'sochi';
        window.location.href = 'direction.html?id=' + encodeURIComponent(dest);
      });
    }
  }

  // Всплывающее уведомление (Toast)
  function showToast(msg){
    let t = document.getElementById('tourToast');
    if(!t){
      t = document.createElement('div');
      t.id = 'tourToast';
      t.className = 'tour-toast';
      document.body.appendChild(t);
    }
    t.innerHTML = '<span>' + msg + '</span>';
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function(){
      t.classList.remove('show');
    }, 3800);
  }

  // Клик по соцсетям (заглушки)
  document.querySelectorAll('[data-social-toast]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      const msg = this.getAttribute('data-social-toast');
      if(msg) showToast(msg);
    });
  });

  // Клик по кликабельным телефонам (информирование о запуске приложения звонка)
  document.querySelectorAll('a[href^="tel:"]').forEach(function(link){
    link.addEventListener('click', function(){
      const phone = this.getAttribute('href').replace('tel:', '');
      showToast('📞 Вызов: ' + phone + ' (открываем телефонное приложение)');
    });
  });

  // Быстрый фильтр на странице направлений (если есть)
  document.querySelectorAll('.catalog-pill').forEach(function(pill){
    pill.addEventListener('click', function(e){
      const cat = this.getAttribute('data-filter');
      if(!cat) return;
      e.preventDefault();
      document.querySelectorAll('.catalog-pill').forEach(p => p.classList.remove('active'));
      this.classList.add('active');
      const cards = document.querySelectorAll('.grid .card');
      cards.forEach(function(card){
        if(cat === 'all'){
          card.style.display = '';
        } else {
          const cardCat = card.getAttribute('data-cat') || '';
          card.style.display = cardCat.includes(cat) ? '' : 'none';
        }
      });
    });
  });

  const io = new IntersectionObserver(es=>{
    es.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('vis'); io.unobserve(e.target);} });
  },{threshold:.12});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.links a').forEach(a=>{
    if(a.getAttribute('href')===path) a.classList.add('active');
  });
  const y = document.getElementById('year');
  if(y) y.textContent = new Date().getFullYear();

  // Tour booking modal for standalone pages
  if (typeof window.openTourModal !== 'function') {
    let tourModalEl = null;

    function ensureTourBookingModal() {
      if (tourModalEl) return tourModalEl;
      tourModalEl = document.getElementById('tourBookingModal');
      if (!tourModalEl) {
        tourModalEl = document.createElement('div');
        tourModalEl.className = 'tour-modal-overlay';
        tourModalEl.id = 'tourBookingModal';
        tourModalEl.setAttribute('role', 'dialog');
        tourModalEl.setAttribute('aria-modal', 'true');
        tourModalEl.innerHTML = [
          '<div class="tour-modal-dialog">',
          '  <button class="tour-modal-close" id="tbmCloseBtn" type="button" aria-label="Закрыть">✕</button>',
          '  <div class="tour-modal-header">',
          '    <div class="tour-modal-tag">⚡ Мгновенное бронирование</div>',
          '    <h3 class="tour-modal-heading" id="tbmHeading">Оформление заявки на тур</h3>',
          '    <div class="tour-modal-selected-card">',
          '      <div class="tour-modal-tour-title" id="tbmTourTitle">Выбранный тур</div>',
          '      <div class="tour-modal-tour-meta">',
          '        <span class="tbm-price" id="tbmTourPrice"></span>',
          '        <span class="tbm-dot" id="tbmDirDot">•</span>',
          '        <span class="tbm-dir" id="tbmTourDir"></span>',
          '        <span class="tbm-b2b" id="tbmTourB2B" style="display:none">💼 Комиссия ТА: 13%</span>',
          '      </div>',
          '    </div>',
          '  </div>',
          '  <form class="tour-modal-form" id="tbmForm" novalidate>',
          '    <div class="tbm-row-2">',
          '      <div class="tbm-field">',
          '        <label for="tbmName">Ваше имя <span class="req">*</span></label>',
          '        <input class="tbm-input" id="tbmName" name="name" type="text" placeholder="Иван Иванов" required autocomplete="name">',
          '      </div>',
          '      <div class="tbm-field">',
          '        <label for="tbmPhone">Номер телефона <span class="req">*</span></label>',
          '        <input class="tbm-input" id="tbmPhone" name="phone" type="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel">',
          '      </div>',
          '    </div>',
          '    <div class="tbm-row-2">',
          '      <div class="tbm-field">',
          '        <label for="tbmDate">Желаемая дата вылета</label>',
          '        <input class="tbm-input" id="tbmDate" name="date" type="text" placeholder="Ближайшие даты">',
          '      </div>',
          '      <div class="tbm-field">',
          '        <label for="tbmTourists">Количество гостей</label>',
          '        <select class="tbm-select" id="tbmTourists" name="tourists">',
          '          <option value="2 взрослых" selected>2 взрослых</option>',
          '          <option value="1 взрослый">1 взрослый</option>',
          '          <option value="2 взр. + 1 реб.">2 взр. + 1 ребенок</option>',
          '          <option value="Семья (2 взр. + 2 дет.)">Семья (2 взр. + 2 дет.)</option>',
          '          <option value="3 взрослых">3 взрослых</option>',
          '          <option value="Компания (4+ чел.)">Компания (4+ гостей)</option>',
          '        </select>',
          '      </div>',
          '    </div>',
          '    <div class="tbm-field">',
          '      <label for="tbmComment">Пожелания (отель, трансфер, питание)</label>',
          '      <input class="tbm-input" id="tbmComment" name="comment" type="text" placeholder="Например: номер с видом, детская кровать, завтраки">',
          '    </div>',
          '    <div class="tbm-error" id="tbmError"></div>',
          '    <label class="tbm-agree">',
          '      <input type="checkbox" id="tbmAgree" checked required>',
          '      <span>Согласен с <a href="privacy.html">политикой конфиденциальности</a></span>',
          '    </label>',
          '    <button type="submit" class="tbm-submit-btn" id="tbmSubmitBtn">',
          '      <span id="tbmSubmitBtnText">Забронировать тур</span>',
          '      <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M4.167 10h11.666m-4.166-4.167L15.833 10l-4.166 4.167" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
          '    </button>',
          '    <div class="tbm-trust">',
          '      <span>⚡ Ответ за 10 мин</span>',
          '      <span>•</span>',
          '      <span>🛡️ Прямой договор туроператора</span>',
          '      <span>•</span>',
          '      <span>💳 0% наценок</span>',
          '    </div>',
          '  </form>',
          '  <div class="tour-modal-success" id="tbmSuccess" style="display:none">',
          '    <div class="tbm-success-icon">✓</div>',
          '    <h3>Заявка на тур успешно принята!</h3>',
          '    <p id="tbmSuccessMsg">Благодарим вас! Персональный менеджер свяжется с вами по указанному телефону в течение 10 минут с подтверждением бронирования.</p>',
          '    <button type="button" class="btn" id="tbmSuccessCloseBtn" style="margin: 0 auto; display: inline-flex;">Отлично, понятно</button>',
          '  </div>',
          '</div>'
        ].join('');
        document.body.appendChild(tourModalEl);

        const closeBtn = tourModalEl.querySelector('#tbmCloseBtn');
        const successCloseBtn = tourModalEl.querySelector('#tbmSuccessCloseBtn');
        if (closeBtn) closeBtn.addEventListener('click', closeTourModal);
        if (successCloseBtn) successCloseBtn.addEventListener('click', closeTourModal);

        tourModalEl.addEventListener('click', function(e) {
          if (e.target === tourModalEl) closeTourModal();
        });

        const phoneInput = tourModalEl.querySelector('#tbmPhone');
        if (phoneInput) {
          phoneInput.addEventListener('input', function(e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            if (!x[2]) {
              e.target.value = x[1] ? (x[1] === '7' || x[1] === '8' ? '+7 ' : '+' + x[1] + ' ') : '';
            } else {
              e.target.value = '+7 (' + x[2] + (x[3] ? ') ' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
            }
          });
        }

        const form = tourModalEl.querySelector('#tbmForm');
        if (form) {
          form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const nameInput = form.querySelector('#tbmName');
            const phoneInput = form.querySelector('#tbmPhone');
            const dateInput = form.querySelector('#tbmDate');
            const touristsInput = form.querySelector('#tbmTourists');
            const commentInput = form.querySelector('#tbmComment');
            const agreeCheck = form.querySelector('#tbmAgree');
            const errEl = form.querySelector('#tbmError');
            const submitBtn = form.querySelector('#tbmSubmitBtn');
            const submitBtnText = form.querySelector('#tbmSubmitBtnText');
            const successBlock = tourModalEl.querySelector('#tbmSuccess');
            const successMsg = tourModalEl.querySelector('#tbmSuccessMsg');

            if (errEl) errEl.style.display = 'none';

            const name = (nameInput ? nameInput.value : '').trim();
            const phone = (phoneInput ? phoneInput.value : '').trim();

            if (!name) {
              if (errEl) { errEl.textContent = 'Пожалуйста, укажите ваше имя'; errEl.style.display = 'block'; }
              if (nameInput) nameInput.focus();
              return;
            }
            if (!phone || phone.replace(/\D/g, '').length < 10) {
              if (errEl) { errEl.textContent = 'Пожалуйста, укажите корректный номер телефона (не менее 10 цифр)'; errEl.style.display = 'block'; }
              if (phoneInput) phoneInput.focus();
              return;
            }
            if (agreeCheck && !agreeCheck.checked) {
              if (errEl) { errEl.textContent = 'Необходимо согласие с политикой конфиденциальности'; errEl.style.display = 'block'; }
              return;
            }

            if (submitBtn) { submitBtn.disabled = true; if (submitBtnText) submitBtnText.textContent = 'Оформляем заявку…'; }

            const currentTourTitle = (tourModalEl.querySelector('#tbmTourTitle') || {}).textContent || '';
            const currentTourPrice = (tourModalEl.querySelector('#tbmTourPrice') || {}).textContent || '';
            const currentTourDir = (tourModalEl.querySelector('#tbmTourDir') || {}).textContent || '';

            const leadData = {
              name: name,
              phone: phone,
              tourTitle: currentTourTitle,
              tourPrice: currentTourPrice,
              direction: currentTourDir,
              date: dateInput ? dateInput.value : '',
              tourists: touristsInput ? touristsInput.value : '2 взрослых',
              comment: commentInput ? commentInput.value : '',
              isB2B: tourModalEl._isAgency || false,
              source: 'standalone_tour_modal',
              time: new Date().toISOString()
            };

            try {
              if (window.EmailLeads && typeof window.EmailLeads.sendLead === 'function') {
                await window.EmailLeads.sendLead(leadData);
              } else {
                await new Promise(r => setTimeout(r, 600));
                const list = JSON.parse(localStorage.getItem('tourput_leads_archive') || '[]');
                list.push(leadData);
                localStorage.setItem('tourput_leads_archive', JSON.stringify(list));
              }

              form.style.display = 'none';
              if (successBlock) {
                if (successMsg) {
                  successMsg.textContent = 'Благодарим вас, ' + name + '! Заявка на тур «' + currentTourTitle + '» принята. Персональный менеджер свяжется с вами в течение 10 минут.';
                }
                successBlock.style.display = 'block';
              }
              showToast('✓ Заявка на тур успешно принята! Звонок через 10 минут.');
            } catch(ex) {
              if (errEl) {
                errEl.textContent = 'Ошибка отправки: ' + (ex.message || ex) + '. Попробуйте снова.';
                errEl.style.display = 'block';
              }
            } finally {
              if (submitBtn) {
                submitBtn.disabled = false;
                if (submitBtnText) submitBtnText.textContent = 'Забронировать тур';
              }
            }
          });
        }
      }
      return tourModalEl;
    }

    function openTourModal(title, price, direction, meta) {
      const modal = ensureTourBookingModal();
      const titleEl = modal.querySelector('#tbmTourTitle');
      const priceEl = modal.querySelector('#tbmTourPrice');
      const dirEl = modal.querySelector('#tbmTourDir');
      const b2bBadge = modal.querySelector('#tbmTourB2B');
      const dirDot = modal.querySelector('#tbmDirDot');
      const form = modal.querySelector('#tbmForm');
      const successBlock = modal.querySelector('#tbmSuccess');
      const errEl = modal.querySelector('#tbmError');
      const submitBtnText = modal.querySelector('#tbmSubmitBtnText');

      const isAgency = meta && meta.isAgency;
      modal._isAgency = isAgency;

      if (titleEl) titleEl.textContent = title || 'Индивидуальный подбор тура';
      if (priceEl) {
        if (price) {
          const pNum = typeof price === 'number' ? price : parseInt(String(price).replace(/\D/g, ''), 10);
          priceEl.textContent = !isNaN(pNum) ? 'от ' + pNum.toLocaleString('ru-RU') + ' ₽' : price;
          priceEl.style.display = 'inline';
        } else {
          priceEl.style.display = 'none';
        }
      }
      if (dirEl) {
        dirEl.textContent = direction || '';
        dirEl.style.display = direction ? 'inline' : 'none';
      }
      if (dirDot) {
        dirDot.style.display = (price && direction) ? 'inline' : 'none';
      }
      if (b2bBadge) {
        b2bBadge.style.display = isAgency ? 'inline-block' : 'none';
      }
      if (submitBtnText) {
        submitBtnText.textContent = isAgency ? 'Забронировать (B2B)' : 'Забронировать тур';
      }

      if (errEl) errEl.style.display = 'none';
      if (form) {
        form.reset();
        form.style.display = 'block';
      }
      if (successBlock) successBlock.style.display = 'none';

      modal.classList.add('open');
      setTimeout(() => {
        const nameInp = modal.querySelector('#tbmName');
        if (nameInp) nameInp.focus();
      }, 80);
    }

    function closeTourModal() {
      if (tourModalEl) {
        tourModalEl.classList.remove('open');
      }
    }

    window.openTourModal = openTourModal;
    window.closeTourModal = closeTourModal;

    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && tourModalEl && tourModalEl.classList.contains('open')) {
        closeTourModal();
      }
    });
  }
})();
