/**
 * ТУР ПУТЬ — Модуль аналитики и учета посещаемости
 * Интерактивный график трафика для панели безопасности и администратора.
 *
 * Архитектура:
 * 1. Smart Hybrid Storage:
 *    - По умолчанию работает мгновенно локально (0ms, offline-first).
 *    - При вводе ключей Supabase мгновенно переключается на облачную базу PostgreSQL
 *      с синхронизацией всех реальных посетителей со всего интернета.
 * 2. Сбор метрик:
 *    - Просмотры страниц (Pageviews)
 *    - Уникальные посетители (Unique Visitors по постоянному visitorId)
 *    - Конверсии в заявки (Leads)
 *    - Топ популярных направлений (Сочи, Алтай, Байкал и т.д.)
 *    - Типы устройств (Мобильные / Десктоп) и источники трафика
 * 3. Высокопроизводительный Canvas-рендерер графиков с Retina-четкостью и интерактивными тултипами.
 */

(function(){
  'use strict';

  const STORAGE_VISITS_KEY = 'turput_visits_log_v2';
  const STORAGE_VID_KEY = 'turput_vid';
  const STORAGE_SID_KEY = 'turput_sid_time';
  const STORAGE_SB_URL = 'turput_supabase_url';
  const STORAGE_SB_KEY = 'turput_supabase_key';
  const DEFAULT_SB_URL = 'https://jbfzzommtuchhoaqsevy.supabase.co';
  const DEFAULT_SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpiZnp6b21tdHVjaGhvYXFzZXZ5Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MjA3NDg3NSwiZXhwIjoyMTA3NjUwODc1fQ.3frZImvFtiplKtyTkOYbrd1-2eJI6F5SZwNiEtcO0hw';

  // Инициализация устойчивого ID посетителя
  function getVisitorId(){
    try {
      let vid = localStorage.getItem(STORAGE_VID_KEY);
      if(!vid){
        vid = 'v_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);
        localStorage.setItem(STORAGE_VID_KEY, vid);
      }
      return vid;
    } catch(e){
      return 'v_anon';
    }
  }

  // Определение типа устройства
  function getDeviceType(){
    const ua = navigator.userAgent || '';
    if(/iPad|tablet|(android(?!.*mobile))/i.test(ua)) return 'Планшет';
    if(/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated/i.test(ua)) return 'Смартфон';
    return 'Компьютер';
  }

  // Определение направления тура из URL
  function detectDirection(){
    try {
      const p = new URLSearchParams(window.location.search);
      const id = p.get('id') || p.get('direction');
      if(id) return id;
      const path = window.location.pathname.toLowerCase();
      if(path.indexOf('sochi') !== -1) return 'sochi';
      if(path.indexOf('altai') !== -1) return 'altai';
      if(path.indexOf('baikal') !== -1) return 'baikal';
      if(path.indexOf('kazan') !== -1) return 'kazan';
      if(path.indexOf('spb') !== -1) return 'spb';
      if(path.indexOf('kmv') !== -1) return 'kmv';
    } catch(e){}
    return 'general';
  }

  // Чистая временная шкала без фантомных данных (100% реальные визиты)
  function generateEmptyTimeline(daysCount){
    daysCount = daysCount || 7;
    const now = new Date();
    const days = [];
    for(let i = daysCount - 1; i >= 0; i--){
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dStr = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
      days.push({
        dateStr: dStr,
        label: label,
        views: 0,
        uniques: 0,
        leads: 0,
        uniqueVids: new Set()
      });
    }
    return days;
  }

  let cachedRemoteVisits = null;
  let lastFetchTime = 0;

  async function fetchRemoteVisits(force){
    const now = Date.now();
    if(!force && cachedRemoteVisits && (now - lastFetchTime < 15000)){
      return cachedRemoteVisits;
    }
    const cfg = TurputAnalytics.getSupabaseConfig();
    if(!cfg.url || !cfg.key) return null;

    const since = new Date();
    since.setDate(since.getDate() - 7);
    const sinceIso = since.toISOString();
    const endpoint = cfg.url.replace(/\/+$/, '') + '/rest/v1/visits?created_at=gte.' + encodeURIComponent(sinceIso) + '&select=*&order=created_at.asc';

    try {
      const resp = await fetch(endpoint, {
        headers: {
          'apikey': cfg.key,
          'Authorization': 'Bearer ' + cfg.key
        }
      });
      if(resp.ok){
        const rows = await resp.json();
        cachedRemoteVisits = rows;
        lastFetchTime = now;
        return rows;
      }
    } catch(e){}
    return null;
  }

  const TurputAnalytics = {
    // Получение настроек Supabase
    getSupabaseConfig: function(){
      try {
        return {
          url: localStorage.getItem(STORAGE_SB_URL) || (window.TURPUT_CONFIG && window.TURPUT_CONFIG.supabaseUrl) || DEFAULT_SB_URL,
          key: localStorage.getItem(STORAGE_SB_KEY) || (window.TURPUT_CONFIG && window.TURPUT_CONFIG.supabaseKey) || DEFAULT_SB_KEY
        };
      } catch(e){
        return { url: DEFAULT_SB_URL, key: DEFAULT_SB_KEY };
      }
    },

    setSupabaseConfig: function(url, key){
      try {
        localStorage.setItem(STORAGE_SB_URL, String(url || '').trim());
        localStorage.setItem(STORAGE_SB_KEY, String(key || '').trim());
      } catch(e){}
    },

    // Локальное хранилище визитов
    getVisits: function(){
      try {
        const raw = localStorage.getItem(STORAGE_VISITS_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch(e){
        return [];
      }
    },

    // Запись просмотра страницы
    trackPageView: function(){
      const vid = getVisitorId();
      const dir = detectDirection();
      const dev = getDeviceType();
      const now = new Date();

      const event = {
        vid: vid,
        page: window.location.pathname || '/',
        direction: dir,
        device: dev,
        ref: document.referrer ? new URL(document.referrer, location.href).hostname : 'Прямой заход',
        ts: now.getTime(),
        date: now.toISOString().slice(0, 10),
        isLead: false
      };

      // Сохраняем локально
      try {
        const visits = this.getVisits();
        visits.push(event);
        localStorage.setItem(STORAGE_VISITS_KEY, JSON.stringify(visits.slice(-500)));
      } catch(e){}

      // Если подключен Supabase — отправляем в облако
      this.sendToSupabase(event);
    },

    // Запись конверсии (отправка заявки)
    trackLead: function(dir){
      const vid = getVisitorId();
      const now = new Date();
      const event = {
        vid: vid,
        page: window.location.pathname || '/',
        direction: dir || detectDirection(),
        device: getDeviceType(),
        ts: now.getTime(),
        date: now.toISOString().slice(0, 10),
        isLead: true
      };

      try {
        const visits = this.getVisits();
        visits.push(event);
        localStorage.setItem(STORAGE_VISITS_KEY, JSON.stringify(visits.slice(-500)));
      } catch(e){}

      this.sendToSupabase(event);
    },

    // Отправка в Supabase REST API (работает без библиотек через стандартный fetch)
    sendToSupabase: async function(event){
      const cfg = this.getSupabaseConfig();
      if(!cfg.url || !cfg.key) return;

      const endpoint = cfg.url.replace(/\/+$/, '') + '/rest/v1/visits';
      try {
        const resp = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': cfg.key,
            'Authorization': 'Bearer ' + cfg.key,
            'Prefer': 'return=minimal'
          },
          body: JSON.stringify({
            visitor_id: event.vid,
            page: event.page,
            direction: event.direction,
            device: event.device,
            referrer: event.ref,
            is_lead: event.isLead
          })
        });

        if((resp.status === 200 || resp.status === 201 || resp.status === 204) && cachedRemoteVisits && Array.isArray(cachedRemoteVisits)){
          cachedRemoteVisits.push({
            visitor_id: event.vid,
            created_at: new Date().toISOString(),
            direction: event.direction,
            is_lead: event.isLead
          });
        }
      } catch(e){
        // Тихо игнорируем сетевые сбои аналитики, чтобы не блокировать интерфейс
      }
    },

    // Проверка соединения с Supabase
    testSupabaseConnection: async function(customUrl, customKey){
      const url = (customUrl || this.getSupabaseConfig().url).replace(/\/+$/, '');
      const key = customKey || this.getSupabaseConfig().key;

      if(!url || !key){
        return { ok: false, error: 'Укажите Project URL и Anon Key' };
      }

      try {
        const resp = await fetch(url + '/rest/v1/visits?limit=1', {
          headers: {
            'apikey': key,
            'Authorization': 'Bearer ' + key
          }
        });

        if(resp.status === 200 || resp.status === 206){
          return { ok: true, message: 'Связь с базой Supabase успешно установлена!' };
        } else if(resp.status === 404){
          return { ok: false, error: 'Таблица "visits" не найдена. Создайте её по SQL-скрипту ниже.' };
        } else {
          return { ok: false, error: 'Ошибка Supabase API: ' + resp.status + ' (' + resp.statusText + ')' };
        }
      } catch(e){
        return { ok: false, error: 'Сетевая ошибка подключения: ' + (e.message || e) };
      }
    },

    // Сводные данные за последние 7 дней (100% реальные данные)
    getTimelineData: function(daysCount){
      daysCount = daysCount || 7;
      const timeline = generateEmptyTimeline(daysCount);
      const dayMap = {};
      timeline.forEach(d => { dayMap[d.dateStr] = d; });

      // Объединяем визиты: если есть данные из Supabase — берем их, иначе локальные
      const localVisits = this.getVisits();
      let allEvents = [];
      if(cachedRemoteVisits && Array.isArray(cachedRemoteVisits)){
        allEvents = cachedRemoteVisits.map(r => ({
          vid: r.visitor_id,
          date: (r.created_at || '').slice(0, 10),
          direction: r.direction,
          isLead: Boolean(r.is_lead)
        }));
      } else {
        allEvents = localVisits;
      }

      const dirScores = {
        'Сочи': 0,
        'Алтай': 0,
        'Байкал': 0,
        'Казань': 0,
        'КМВ': 0,
        'СПб': 0
      };

      const globalUniqueVids = new Set();
      let totalViews = 0, totalLeads = 0;

      allEvents.forEach(v => {
        const targetDay = dayMap[v.date];
        if(targetDay){
          if(v.isLead){
            targetDay.leads++;
            totalLeads++;
          } else {
            targetDay.views++;
            totalViews++;
            if(v.vid) targetDay.uniqueVids.add(v.vid);
          }
        }
        if(!v.isLead && v.vid) globalUniqueVids.add(v.vid);

        if(v.direction === 'sochi') dirScores['Сочи']++;
        else if(v.direction === 'altai') dirScores['Алтай']++;
        else if(v.direction === 'baikal') dirScores['Байкал']++;
        else if(v.direction === 'kazan') dirScores['Казань']++;
        else if(v.direction === 'kmv') dirScores['КМВ']++;
        else if(v.direction === 'spb') dirScores['СПб']++;
      });

      timeline.forEach(d => {
        d.uniques = d.uniqueVids ? d.uniqueVids.size : 0;
        delete d.uniqueVids;
      });

      const convRate = totalViews > 0 ? ((totalLeads / totalViews) * 100).toFixed(1) : '0.0';

      return {
        timeline: timeline,
        totals: {
          views: totalViews,
          uniques: globalUniqueVids.size,
          leads: totalLeads,
          conversion: convRate + '%'
        },
        topDirections: dirScores,
        isLiveCloud: Boolean(cachedRemoteVisits && Array.isArray(cachedRemoteVisits))
      };
    },

    // Синхронизация данных с облачной базой Supabase
    syncFromSupabase: async function(force){
      return await fetchRemoteVisits(force);
    },

    // Отрисовка интерактивного графика на HTML5 Canvas
    renderCanvasChart: function(canvas, activeRange){
      if(!canvas) return;
      const ctx = canvas.getContext('2d');
      if(!ctx) return;

      const data = this.getTimelineData(activeRange || 7);
      const points = data.timeline;

      // Настройка разрешения Canvas под Retina
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.getBoundingClientRect();
      const W = Math.max(280, Math.floor(rect.width || canvas.parentElement.clientWidth || 540));
      const H = 200;

      canvas.width = Math.floor(W * dpr);
      canvas.height = Math.floor(H * dpr);
      canvas.style.width = W + 'px';
      canvas.style.height = H + 'px';

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, W, H);

      const padL = 36, padR = 20, padT = 24, padB = 28;
      const plotW = W - padL - padR;
      const plotH = H - padT - padB;

      // Поиск максимума для шкалы Y на основе реальных данных
      let maxFound = 0;
      points.forEach(p => {
        if(p.views > maxFound) maxFound = p.views;
        if(p.uniques > maxFound) maxFound = p.uniques;
        if(p.leads > maxFound) maxFound = p.leads;
      });

      let maxVal = 5;
      if(maxFound > 4){
        maxVal = Math.ceil((maxFound * 1.25) / 5) * 5;
      }

      // Горизонтальные линии сетки и подписи
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
      ctx.lineWidth = 1;
      ctx.fillStyle = 'rgba(154, 168, 199, 0.6)';
      ctx.font = '10px -apple-system, sans-serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';

      const gridRows = 4;
      for(let i = 0; i <= gridRows; i++){
        const y = padT + (plotH / gridRows) * i;
        const val = Math.round(maxVal - (maxVal / gridRows) * i);
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(W - padR, y);
        ctx.stroke();
        ctx.fillText(val, padL - 6, y);
      }

      // Сообщение, если база только что подключена и данных еще мало
      if(data.totals.views === 0){
        ctx.fillStyle = 'rgba(154, 168, 199, 0.55)';
        ctx.font = '12px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('⚡ База Supabase подключена. Ожидаются первые посещения...', W / 2, H / 2 - 4);
      }

      // Расчет координат точек
      const coordsViews = [];
      const coordsUniq = [];
      const coordsLeads = [];

      const stepX = plotW / (points.length - 1);
      points.forEach((p, idx) => {
        const x = padL + stepX * idx;
        const yV = padT + plotH - (p.views / maxVal) * plotH;
        const yU = padT + plotH - (p.uniques / maxVal) * plotH;
        const yL = padT + plotH - ((p.leads * 15) / maxVal) * plotH; // Масштабируем лиды для наглядности
        coordsViews.push({ x, y: yV, val: p.views, label: p.label, leads: p.leads, uniques: p.uniques });
        coordsUniq.push({ x, y: yU, val: p.uniques });
        coordsLeads.push({ x, y: yL, val: p.leads });

        // Подписи дат внизу
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillStyle = 'rgba(154, 168, 199, 0.7)';
        ctx.fillText(p.label, x, H - padB + 8);
      });

      // Функция отрисовки плавной кривой Безье с градиентной заливкой
      function drawSmoothLine(coords, strokeColor, fillColor, lineWidth){
        if(coords.length < 2) return;

        // Линия
        ctx.beginPath();
        ctx.moveTo(coords[0].x, coords[0].y);

        for(let i = 0; i < coords.length - 1; i++){
          const cpX = (coords[i].x + coords[i + 1].x) / 2;
          ctx.bezierCurveTo(cpX, coords[i].y, cpX, coords[i + 1].y, coords[i + 1].x, coords[i + 1].y);
        }

        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = lineWidth || 2;
        ctx.stroke();

        // Заливка под графиком
        if(fillColor){
          ctx.lineTo(coords[coords.length - 1].x, padT + plotH);
          ctx.lineTo(coords[0].x, padT + plotH);
          ctx.closePath();
          ctx.fillStyle = fillColor;
          ctx.fill();
        }

        // Светящиеся узлы
        coords.forEach(pt => {
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 3.5, 0, Math.PI * 2);
          ctx.fillStyle = strokeColor;
          ctx.fill();
        });
      }

      // 1. Градиент и кривая для Просмотров (Pageviews — Cyan/Blue)
      const gradViews = ctx.createLinearGradient(0, padT, 0, padT + plotH);
      gradViews.addColorStop(0, 'rgba(56, 189, 248, 0.28)');
      gradViews.addColorStop(1, 'rgba(56, 189, 248, 0.00)');
      drawSmoothLine(coordsViews, '#38bdf8', gradViews, 2.5);

      // 2. Градиент и кривая для Уникальных посетителей (Uniques — Green)
      const gradUniq = ctx.createLinearGradient(0, padT, 0, padT + plotH);
      gradUniq.addColorStop(0, 'rgba(34, 197, 94, 0.20)');
      gradUniq.addColorStop(1, 'rgba(34, 197, 94, 0.00)');
      drawSmoothLine(coordsUniq, '#22c55e', gradUniq, 2);

      // 3. Точки заявок (Leads — Amber/Gold)
      drawSmoothLine(coordsLeads, '#f59e0b', null, 1.8);

      ctx.restore();

      // Сохраняем вычисленные координаты для тултипов при движении мыши
      canvas._coords = coordsViews;
    }
  };

  // Автоматический трекинг просмотра страницы при загрузке
  window.addEventListener('DOMContentLoaded', function(){
    TurputAnalytics.trackPageView();
  });

  window.TurputAnalytics = TurputAnalytics;
})();
